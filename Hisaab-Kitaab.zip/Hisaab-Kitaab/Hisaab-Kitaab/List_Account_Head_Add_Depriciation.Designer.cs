﻿namespace Hisaab_Kitaab
{
    partial class List_Account_Head_Add_Depriciation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(List_Account_Head_Add_Depriciation));
            this.button_DepModify = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_DRYRemove = new System.Windows.Forms.Button();
            this.button_DYRModify = new System.Windows.Forms.Button();
            this.button_DYRAdd = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label_DYRRate = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label_DYRYearNo = new System.Windows.Forms.Label();
            this.dataGridView_DEPYEARLYRATE = new System.Windows.Forms.DataGridView();
            this.DepRateID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DepCardID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.YEARNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.YEARRATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label_Life = new System.Windows.Forms.Label();
            this.textBox_SalvageVal = new System.Windows.Forms.TextBox();
            this.label_DepSalVal = new System.Windows.Forms.Label();
            this.comboBoxLife = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox_UploadPicture = new System.Windows.Forms.GroupBox();
            this.button_UploadPic = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.dateTimePicker_PurchaseDate = new System.Windows.Forms.DateTimePicker();
            this.groupBox_DepMethod = new System.Windows.Forms.GroupBox();
            this.radioButton_DepSLM = new System.Windows.Forms.RadioButton();
            this.radioButton_DepRBM = new System.Windows.Forms.RadioButton();
            this.label_Percent = new System.Windows.Forms.Label();
            this.button_ParentHeadChoose = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxParentHead = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxAccountTitle = new System.Windows.Forms.TextBox();
            this.label_Dep = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label_DepPurchaseDate = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DEPYEARLYRATE)).BeginInit();
            this.groupBox_UploadPicture.SuspendLayout();
            this.groupBox_DepMethod.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_DepModify
            // 
            this.button_DepModify.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_DepModify.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.button_DepModify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_DepModify.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_DepModify.ForeColor = System.Drawing.Color.White;
            this.button_DepModify.Location = new System.Drawing.Point(914, 562);
            this.button_DepModify.Name = "button_DepModify";
            this.button_DepModify.Size = new System.Drawing.Size(192, 44);
            this.button_DepModify.TabIndex = 104;
            this.button_DepModify.Text = "Modify";
            this.button_DepModify.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.button_DRYRemove);
            this.panel1.Controls.Add(this.button_DYRModify);
            this.panel1.Controls.Add(this.button_DYRAdd);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.label_DYRRate);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.label_DYRYearNo);
            this.panel1.Controls.Add(this.dataGridView_DEPYEARLYRATE);
            this.panel1.Enabled = false;
            this.panel1.Location = new System.Drawing.Point(786, 118);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(320, 408);
            this.panel1.TabIndex = 124;
            this.panel1.EnabledChanged += new System.EventHandler(this.panel1_EnabledChanged);
            // 
            // button_DRYRemove
            // 
            this.button_DRYRemove.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_DRYRemove.BackColor = System.Drawing.Color.White;
            this.button_DRYRemove.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_DRYRemove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_DRYRemove.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_DRYRemove.ForeColor = System.Drawing.Color.Black;
            this.button_DRYRemove.Location = new System.Drawing.Point(222, 360);
            this.button_DRYRemove.Name = "button_DRYRemove";
            this.button_DRYRemove.Size = new System.Drawing.Size(93, 37);
            this.button_DRYRemove.TabIndex = 67;
            this.button_DRYRemove.Text = "Remove";
            this.button_DRYRemove.UseVisualStyleBackColor = false;
            // 
            // button_DYRModify
            // 
            this.button_DYRModify.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_DYRModify.BackColor = System.Drawing.Color.White;
            this.button_DYRModify.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_DYRModify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_DYRModify.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_DYRModify.ForeColor = System.Drawing.Color.Black;
            this.button_DYRModify.Location = new System.Drawing.Point(222, 314);
            this.button_DYRModify.Name = "button_DYRModify";
            this.button_DYRModify.Size = new System.Drawing.Size(93, 37);
            this.button_DYRModify.TabIndex = 66;
            this.button_DYRModify.Text = "Modify";
            this.button_DYRModify.UseVisualStyleBackColor = false;
            // 
            // button_DYRAdd
            // 
            this.button_DYRAdd.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_DYRAdd.BackColor = System.Drawing.Color.White;
            this.button_DYRAdd.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_DYRAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_DYRAdd.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_DYRAdd.ForeColor = System.Drawing.Color.Black;
            this.button_DYRAdd.Location = new System.Drawing.Point(222, 265);
            this.button_DYRAdd.Name = "button_DYRAdd";
            this.button_DYRAdd.Size = new System.Drawing.Size(93, 37);
            this.button_DYRAdd.TabIndex = 60;
            this.button_DYRAdd.Text = "Add";
            this.button_DYRAdd.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label3.Location = new System.Drawing.Point(166, 336);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 24);
            this.label3.TabIndex = 65;
            this.label3.Text = "%";
            // 
            // textBox4
            // 
            this.textBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox4.Location = new System.Drawing.Point(103, 333);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(55, 32);
            this.textBox4.TabIndex = 64;
            // 
            // label_DYRRate
            // 
            this.label_DYRRate.AutoSize = true;
            this.label_DYRRate.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DYRRate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_DYRRate.Location = new System.Drawing.Point(32, 336);
            this.label_DYRRate.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_DYRRate.Name = "label_DYRRate";
            this.label_DYRRate.Size = new System.Drawing.Size(64, 24);
            this.label_DYRRate.TabIndex = 63;
            this.label_DYRRate.Text = "Rate:";
            // 
            // textBox3
            // 
            this.textBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox3.Location = new System.Drawing.Point(103, 290);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(55, 32);
            this.textBox3.TabIndex = 62;
            // 
            // label_DYRYearNo
            // 
            this.label_DYRYearNo.AutoSize = true;
            this.label_DYRYearNo.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DYRYearNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_DYRYearNo.Location = new System.Drawing.Point(11, 293);
            this.label_DYRYearNo.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_DYRYearNo.Name = "label_DYRYearNo";
            this.label_DYRYearNo.Size = new System.Drawing.Size(85, 24);
            this.label_DYRYearNo.TabIndex = 61;
            this.label_DYRYearNo.Text = "Year #:";
            // 
            // dataGridView_DEPYEARLYRATE
            // 
            this.dataGridView_DEPYEARLYRATE.AllowUserToAddRows = false;
            this.dataGridView_DEPYEARLYRATE.AllowUserToDeleteRows = false;
            this.dataGridView_DEPYEARLYRATE.AllowUserToResizeColumns = false;
            this.dataGridView_DEPYEARLYRATE.AllowUserToResizeRows = false;
            this.dataGridView_DEPYEARLYRATE.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_DEPYEARLYRATE.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DepRateID,
            this.DepCardID,
            this.YEARNO,
            this.YEARRATE});
            this.dataGridView_DEPYEARLYRATE.Enabled = false;
            this.dataGridView_DEPYEARLYRATE.Location = new System.Drawing.Point(6, 4);
            this.dataGridView_DEPYEARLYRATE.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.dataGridView_DEPYEARLYRATE.Name = "dataGridView_DEPYEARLYRATE";
            this.dataGridView_DEPYEARLYRATE.RowTemplate.Height = 24;
            this.dataGridView_DEPYEARLYRATE.Size = new System.Drawing.Size(309, 252);
            this.dataGridView_DEPYEARLYRATE.TabIndex = 59;
            // 
            // DepRateID
            // 
            this.DepRateID.HeaderText = "DepRateID";
            this.DepRateID.Name = "DepRateID";
            this.DepRateID.Visible = false;
            // 
            // DepCardID
            // 
            this.DepCardID.HeaderText = "DepCardID";
            this.DepCardID.Name = "DepCardID";
            this.DepCardID.Visible = false;
            // 
            // YEARNO
            // 
            this.YEARNO.HeaderText = "Year #";
            this.YEARNO.Name = "YEARNO";
            // 
            // YEARRATE
            // 
            this.YEARRATE.HeaderText = "Depriciation Rate";
            this.YEARRATE.Name = "YEARRATE";
            // 
            // label_Life
            // 
            this.label_Life.AutoSize = true;
            this.label_Life.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Life.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_Life.Location = new System.Drawing.Point(133, 288);
            this.label_Life.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_Life.Name = "label_Life";
            this.label_Life.Size = new System.Drawing.Size(54, 24);
            this.label_Life.TabIndex = 118;
            this.label_Life.Text = "Life:";
            // 
            // textBox_SalvageVal
            // 
            this.textBox_SalvageVal.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_SalvageVal.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SalvageVal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox_SalvageVal.Location = new System.Drawing.Point(199, 333);
            this.textBox_SalvageVal.Name = "textBox_SalvageVal";
            this.textBox_SalvageVal.ReadOnly = true;
            this.textBox_SalvageVal.Size = new System.Drawing.Size(184, 32);
            this.textBox_SalvageVal.TabIndex = 122;
            // 
            // label_DepSalVal
            // 
            this.label_DepSalVal.AutoSize = true;
            this.label_DepSalVal.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DepSalVal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_DepSalVal.Location = new System.Drawing.Point(27, 333);
            this.label_DepSalVal.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_DepSalVal.Name = "label_DepSalVal";
            this.label_DepSalVal.Size = new System.Drawing.Size(160, 24);
            this.label_DepSalVal.TabIndex = 121;
            this.label_DepSalVal.Text = "Salvage Value:";
            // 
            // comboBoxLife
            // 
            this.comboBoxLife.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxLife.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxLife.Enabled = false;
            this.comboBoxLife.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxLife.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.comboBoxLife.FormattingEnabled = true;
            this.comboBoxLife.Items.AddRange(new object[] {
            "Months",
            "Years"});
            this.comboBoxLife.Location = new System.Drawing.Point(292, 285);
            this.comboBoxLife.Name = "comboBoxLife";
            this.comboBoxLife.Size = new System.Drawing.Size(91, 32);
            this.comboBoxLife.TabIndex = 120;
            // 
            // textBox2
            // 
            this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox2.Location = new System.Drawing.Point(199, 285);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(87, 32);
            this.textBox2.TabIndex = 119;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox1.Location = new System.Drawing.Point(199, 239);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(87, 32);
            this.textBox1.TabIndex = 116;
            // 
            // groupBox_UploadPicture
            // 
            this.groupBox_UploadPicture.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox_UploadPicture.Controls.Add(this.button_UploadPic);
            this.groupBox_UploadPicture.Controls.Add(this.pictureBox1);
            this.groupBox_UploadPicture.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_UploadPicture.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.groupBox_UploadPicture.Location = new System.Drawing.Point(513, 189);
            this.groupBox_UploadPicture.Name = "groupBox_UploadPicture";
            this.groupBox_UploadPicture.Size = new System.Drawing.Size(242, 337);
            this.groupBox_UploadPicture.TabIndex = 114;
            this.groupBox_UploadPicture.TabStop = false;
            this.groupBox_UploadPicture.Text = "Upload Picture:";
            // 
            // button_UploadPic
            // 
            this.button_UploadPic.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_UploadPic.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.button_UploadPic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_UploadPic.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_UploadPic.ForeColor = System.Drawing.Color.White;
            this.button_UploadPic.Location = new System.Drawing.Point(27, 274);
            this.button_UploadPic.Name = "button_UploadPic";
            this.button_UploadPic.Size = new System.Drawing.Size(192, 44);
            this.button_UploadPic.TabIndex = 26;
            this.button_UploadPic.Text = "Upload";
            this.button_UploadPic.UseVisualStyleBackColor = false;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(786, 84);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(295, 28);
            this.checkBox1.TabIndex = 123;
            this.checkBox1.Text = "Depriciation Yearly Rates:";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // dateTimePicker_PurchaseDate
            // 
            this.dateTimePicker_PurchaseDate.CalendarForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.dateTimePicker_PurchaseDate.CalendarMonthBackground = System.Drawing.Color.White;
            this.dateTimePicker_PurchaseDate.CalendarTitleBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.dateTimePicker_PurchaseDate.CalendarTitleForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(19)))), ((int)(((byte)(0)))));
            this.dateTimePicker_PurchaseDate.CustomFormat = "dd-MMM-yyy";
            this.dateTimePicker_PurchaseDate.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_PurchaseDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_PurchaseDate.Location = new System.Drawing.Point(199, 189);
            this.dateTimePicker_PurchaseDate.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.dateTimePicker_PurchaseDate.Name = "dateTimePicker_PurchaseDate";
            this.dateTimePicker_PurchaseDate.Size = new System.Drawing.Size(288, 32);
            this.dateTimePicker_PurchaseDate.TabIndex = 105;
            // 
            // groupBox_DepMethod
            // 
            this.groupBox_DepMethod.Controls.Add(this.radioButton_DepSLM);
            this.groupBox_DepMethod.Controls.Add(this.radioButton_DepRBM);
            this.groupBox_DepMethod.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.groupBox_DepMethod.Location = new System.Drawing.Point(84, 381);
            this.groupBox_DepMethod.Name = "groupBox_DepMethod";
            this.groupBox_DepMethod.Size = new System.Drawing.Size(403, 145);
            this.groupBox_DepMethod.TabIndex = 115;
            this.groupBox_DepMethod.TabStop = false;
            this.groupBox_DepMethod.Text = "Method:";
            // 
            // radioButton_DepSLM
            // 
            this.radioButton_DepSLM.AutoSize = true;
            this.radioButton_DepSLM.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_DepSLM.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.radioButton_DepSLM.Location = new System.Drawing.Point(85, 85);
            this.radioButton_DepSLM.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.radioButton_DepSLM.Name = "radioButton_DepSLM";
            this.radioButton_DepSLM.Size = new System.Drawing.Size(200, 28);
            this.radioButton_DepSLM.TabIndex = 3;
            this.radioButton_DepSLM.TabStop = true;
            this.radioButton_DepSLM.Text = "Single Line Method";
            this.radioButton_DepSLM.UseVisualStyleBackColor = true;
            // 
            // radioButton_DepRBM
            // 
            this.radioButton_DepRBM.AutoSize = true;
            this.radioButton_DepRBM.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_DepRBM.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.radioButton_DepRBM.Location = new System.Drawing.Point(85, 43);
            this.radioButton_DepRBM.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.radioButton_DepRBM.Name = "radioButton_DepRBM";
            this.radioButton_DepRBM.Size = new System.Drawing.Size(260, 28);
            this.radioButton_DepRBM.TabIndex = 2;
            this.radioButton_DepRBM.TabStop = true;
            this.radioButton_DepRBM.Text = "Reducing Balance Method";
            this.radioButton_DepRBM.UseVisualStyleBackColor = true;
            // 
            // label_Percent
            // 
            this.label_Percent.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_Percent.AutoSize = true;
            this.label_Percent.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Percent.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_Percent.Location = new System.Drawing.Point(294, 242);
            this.label_Percent.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_Percent.Name = "label_Percent";
            this.label_Percent.Size = new System.Drawing.Size(34, 24);
            this.label_Percent.TabIndex = 117;
            this.label_Percent.Text = "%";
            // 
            // button_ParentHeadChoose
            // 
            this.button_ParentHeadChoose.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_ParentHeadChoose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.button_ParentHeadChoose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ParentHeadChoose.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ParentHeadChoose.ForeColor = System.Drawing.Color.White;
            this.button_ParentHeadChoose.Location = new System.Drawing.Point(605, 85);
            this.button_ParentHeadChoose.Name = "button_ParentHeadChoose";
            this.button_ParentHeadChoose.Size = new System.Drawing.Size(150, 38);
            this.button_ParentHeadChoose.TabIndex = 113;
            this.button_ParentHeadChoose.Text = "Choose";
            this.button_ParentHeadChoose.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_ParentHeadChoose.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label9.Location = new System.Drawing.Point(45, 90);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(142, 24);
            this.label9.TabIndex = 112;
            this.label9.Text = "Parent Head:";
            // 
            // textBoxParentHead
            // 
            this.textBoxParentHead.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxParentHead.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxParentHead.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBoxParentHead.Location = new System.Drawing.Point(199, 90);
            this.textBoxParentHead.Name = "textBoxParentHead";
            this.textBoxParentHead.ReadOnly = true;
            this.textBoxParentHead.Size = new System.Drawing.Size(400, 32);
            this.textBoxParentHead.TabIndex = 111;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label11.Location = new System.Drawing.Point(37, 140);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(149, 24);
            this.label11.TabIndex = 109;
            this.label11.Text = "Account Title:";
            // 
            // textBoxAccountTitle
            // 
            this.textBoxAccountTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxAccountTitle.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAccountTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBoxAccountTitle.Location = new System.Drawing.Point(199, 140);
            this.textBoxAccountTitle.Name = "textBoxAccountTitle";
            this.textBoxAccountTitle.ReadOnly = true;
            this.textBoxAccountTitle.Size = new System.Drawing.Size(556, 32);
            this.textBoxAccountTitle.TabIndex = 108;
            // 
            // label_Dep
            // 
            this.label_Dep.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_Dep.AutoSize = true;
            this.label_Dep.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Dep.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_Dep.Location = new System.Drawing.Point(467, 28);
            this.label_Dep.Name = "label_Dep";
            this.label_Dep.Size = new System.Drawing.Size(288, 29);
            this.label_Dep.TabIndex = 110;
            this.label_Dep.Text = "Depriciation Properties";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label4.Location = new System.Drawing.Point(127, 242);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 24);
            this.label4.TabIndex = 107;
            this.label4.Text = "Rate:";
            // 
            // label_DepPurchaseDate
            // 
            this.label_DepPurchaseDate.AutoSize = true;
            this.label_DepPurchaseDate.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DepPurchaseDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_DepPurchaseDate.Location = new System.Drawing.Point(26, 189);
            this.label_DepPurchaseDate.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_DepPurchaseDate.Name = "label_DepPurchaseDate";
            this.label_DepPurchaseDate.Size = new System.Drawing.Size(163, 24);
            this.label_DepPurchaseDate.TabIndex = 106;
            this.label_DepPurchaseDate.Text = "Purchase Date:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(27, 43);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(192, 214);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // List_Account_Head_Add_Depriciation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1133, 625);
            this.Controls.Add(this.button_DepModify);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label_Life);
            this.Controls.Add(this.textBox_SalvageVal);
            this.Controls.Add(this.label_DepSalVal);
            this.Controls.Add(this.comboBoxLife);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.groupBox_UploadPicture);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.dateTimePicker_PurchaseDate);
            this.Controls.Add(this.groupBox_DepMethod);
            this.Controls.Add(this.label_Percent);
            this.Controls.Add(this.button_ParentHeadChoose);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBoxParentHead);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBoxAccountTitle);
            this.Controls.Add(this.label_Dep);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label_DepPurchaseDate);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "List_Account_Head_Add_Depriciation";
            this.Text = "Add Depriciation Properties";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DEPYEARLYRATE)).EndInit();
            this.groupBox_UploadPicture.ResumeLayout(false);
            this.groupBox_DepMethod.ResumeLayout(false);
            this.groupBox_DepMethod.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_DepModify;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_DRYRemove;
        private System.Windows.Forms.Button button_DYRModify;
        private System.Windows.Forms.Button button_DYRAdd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label_DYRRate;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label_DYRYearNo;
        private System.Windows.Forms.DataGridView dataGridView_DEPYEARLYRATE;
        private System.Windows.Forms.DataGridViewTextBoxColumn DepRateID;
        private System.Windows.Forms.DataGridViewTextBoxColumn DepCardID;
        private System.Windows.Forms.DataGridViewTextBoxColumn YEARNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn YEARRATE;
        private System.Windows.Forms.Label label_Life;
        private System.Windows.Forms.TextBox textBox_SalvageVal;
        private System.Windows.Forms.Label label_DepSalVal;
        private System.Windows.Forms.ComboBox comboBoxLife;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox_UploadPicture;
        private System.Windows.Forms.Button button_UploadPic;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker_PurchaseDate;
        private System.Windows.Forms.GroupBox groupBox_DepMethod;
        private System.Windows.Forms.RadioButton radioButton_DepSLM;
        private System.Windows.Forms.RadioButton radioButton_DepRBM;
        private System.Windows.Forms.Label label_Percent;
        private System.Windows.Forms.Button button_ParentHeadChoose;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxParentHead;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxAccountTitle;
        private System.Windows.Forms.Label label_Dep;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label_DepPurchaseDate;
    }
}