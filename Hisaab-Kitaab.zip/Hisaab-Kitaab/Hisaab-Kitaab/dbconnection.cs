﻿namespace Hisaab_Kitaab
{


    partial class dbconnection
    {
    }
}

namespace Hisaab_Kitaab.dbconnectionTableAdapters {
    
    
    public partial class ACCOUNT_HEADSTableAdapter {
    }
}
