﻿namespace Hisaab_Kitaab
{
    partial class List_Account_Head_Add_Attributes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(List_Account_Head_Add_Attributes));
            this.button_ParentHeadChoose = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxParentHead = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxAccountTitle = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBoxUnits = new System.Windows.Forms.ComboBox();
            this.buttonModify = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_ParentHeadChoose
            // 
            this.button_ParentHeadChoose.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_ParentHeadChoose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.button_ParentHeadChoose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ParentHeadChoose.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ParentHeadChoose.ForeColor = System.Drawing.Color.White;
            this.button_ParentHeadChoose.Location = new System.Drawing.Point(581, 64);
            this.button_ParentHeadChoose.Name = "button_ParentHeadChoose";
            this.button_ParentHeadChoose.Size = new System.Drawing.Size(150, 38);
            this.button_ParentHeadChoose.TabIndex = 15;
            this.button_ParentHeadChoose.Text = "Choose";
            this.button_ParentHeadChoose.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_ParentHeadChoose.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label3.Location = new System.Drawing.Point(21, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(142, 24);
            this.label3.TabIndex = 14;
            this.label3.Text = "Parent Head:";
            // 
            // textBoxParentHead
            // 
            this.textBoxParentHead.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxParentHead.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxParentHead.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBoxParentHead.Location = new System.Drawing.Point(175, 69);
            this.textBoxParentHead.Name = "textBoxParentHead";
            this.textBoxParentHead.ReadOnly = true;
            this.textBoxParentHead.Size = new System.Drawing.Size(400, 32);
            this.textBoxParentHead.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label2.Location = new System.Drawing.Point(13, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 24);
            this.label2.TabIndex = 12;
            this.label2.Text = "Account Title:";
            // 
            // textBoxAccountTitle
            // 
            this.textBoxAccountTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxAccountTitle.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAccountTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBoxAccountTitle.Location = new System.Drawing.Point(175, 108);
            this.textBoxAccountTitle.Name = "textBoxAccountTitle";
            this.textBoxAccountTitle.ReadOnly = true;
            this.textBoxAccountTitle.Size = new System.Drawing.Size(556, 32);
            this.textBoxAccountTitle.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label1.Location = new System.Drawing.Point(48, 146);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 24);
            this.label1.TabIndex = 17;
            this.label1.Text = "Land Size:";
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox1.Location = new System.Drawing.Point(175, 146);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(116, 32);
            this.textBox1.TabIndex = 16;
            // 
            // comboBoxUnits
            // 
            this.comboBoxUnits.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxUnits.DropDownHeight = 100;
            this.comboBoxUnits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxUnits.Enabled = false;
            this.comboBoxUnits.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxUnits.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.comboBoxUnits.FormattingEnabled = true;
            this.comboBoxUnits.IntegralHeight = false;
            this.comboBoxUnits.Items.AddRange(new object[] {
            "sq ft",
            "sq cm",
            "sq in ",
            "sq km",
            "sq m",
            "sq mile",
            "sq yd",
            "acre",
            "ha",
            "Custom"});
            this.comboBoxUnits.Location = new System.Drawing.Point(297, 146);
            this.comboBoxUnits.Name = "comboBoxUnits";
            this.comboBoxUnits.Size = new System.Drawing.Size(91, 32);
            this.comboBoxUnits.TabIndex = 20;
            // 
            // buttonModify
            // 
            this.buttonModify.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonModify.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.buttonModify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonModify.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonModify.ForeColor = System.Drawing.Color.White;
            this.buttonModify.Location = new System.Drawing.Point(297, 207);
            this.buttonModify.Name = "buttonModify";
            this.buttonModify.Size = new System.Drawing.Size(150, 44);
            this.buttonModify.TabIndex = 25;
            this.buttonModify.Text = "Modify";
            this.buttonModify.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label4.Location = new System.Drawing.Point(314, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 29);
            this.label4.TabIndex = 26;
            this.label4.Text = "Attributes";
            // 
            // List_Account_Head_Add_Attributes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(744, 273);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.buttonModify);
            this.Controls.Add(this.comboBoxUnits);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button_ParentHeadChoose);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxParentHead);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxAccountTitle);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "List_Account_Head_Add_Attributes";
            this.Text = "Attributes";
            this.Load += new System.EventHandler(this.List_Account_Head_Add_Attributes_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_ParentHeadChoose;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxParentHead;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxAccountTitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBoxUnits;
        private System.Windows.Forms.Button buttonModify;
        private System.Windows.Forms.Label label4;
    }
}