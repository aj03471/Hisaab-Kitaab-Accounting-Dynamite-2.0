﻿namespace Hisaab_Kitaab
{
    partial class List_Account_Head_Add_Attr_Dep
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(List_Account_Head_Add_Attr_Dep));
            this.button_DepModify = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_DRYRemove = new System.Windows.Forms.Button();
            this.button_DYRModify = new System.Windows.Forms.Button();
            this.button_DYRAdd = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label_DYRRate = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label_DYRYearNo = new System.Windows.Forms.Label();
            this.dataGridView_DEPYEARLYRATE = new System.Windows.Forms.DataGridView();
            this.DepRateID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DepCardID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.YEARNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.YEARRATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.radioButton_DepSLM = new System.Windows.Forms.RadioButton();
            this.radioButton_DepRBM = new System.Windows.Forms.RadioButton();
            this.button_UploadPic = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label_Life = new System.Windows.Forms.Label();
            this.textBox_SalvageVal = new System.Windows.Forms.TextBox();
            this.label_DepSalVal = new System.Windows.Forms.Label();
            this.comboBoxLife = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox_UploadPicture = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.dateTimePicker_PurchaseDate = new System.Windows.Forms.DateTimePicker();
            this.groupBox_DepMethod = new System.Windows.Forms.GroupBox();
            this.label_Percent = new System.Windows.Forms.Label();
            this.button_ParentHeadChoose = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxParentHead = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxAccountTitle = new System.Windows.Forms.TextBox();
            this.label_Dep = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label_DepPurchaseDate = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DEPYEARLYRATE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox_UploadPicture.SuspendLayout();
            this.groupBox_DepMethod.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_DepModify
            // 
            this.button_DepModify.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_DepModify.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.button_DepModify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_DepModify.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_DepModify.ForeColor = System.Drawing.Color.White;
            this.button_DepModify.Location = new System.Drawing.Point(918, 578);
            this.button_DepModify.Name = "button_DepModify";
            this.button_DepModify.Size = new System.Drawing.Size(192, 44);
            this.button_DepModify.TabIndex = 125;
            this.button_DepModify.Text = "Modify";
            this.button_DepModify.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.button_DRYRemove);
            this.panel1.Controls.Add(this.button_DYRModify);
            this.panel1.Controls.Add(this.button_DYRAdd);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.label_DYRRate);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.label_DYRYearNo);
            this.panel1.Controls.Add(this.dataGridView_DEPYEARLYRATE);
            this.panel1.Enabled = false;
            this.panel1.Location = new System.Drawing.Point(790, 110);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(320, 449);
            this.panel1.TabIndex = 145;
            // 
            // button_DRYRemove
            // 
            this.button_DRYRemove.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_DRYRemove.BackColor = System.Drawing.Color.White;
            this.button_DRYRemove.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_DRYRemove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_DRYRemove.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_DRYRemove.ForeColor = System.Drawing.Color.Black;
            this.button_DRYRemove.Location = new System.Drawing.Point(222, 400);
            this.button_DRYRemove.Name = "button_DRYRemove";
            this.button_DRYRemove.Size = new System.Drawing.Size(93, 37);
            this.button_DRYRemove.TabIndex = 67;
            this.button_DRYRemove.Text = "Remove";
            this.button_DRYRemove.UseVisualStyleBackColor = false;
            // 
            // button_DYRModify
            // 
            this.button_DYRModify.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_DYRModify.BackColor = System.Drawing.Color.White;
            this.button_DYRModify.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_DYRModify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_DYRModify.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_DYRModify.ForeColor = System.Drawing.Color.Black;
            this.button_DYRModify.Location = new System.Drawing.Point(222, 350);
            this.button_DYRModify.Name = "button_DYRModify";
            this.button_DYRModify.Size = new System.Drawing.Size(93, 37);
            this.button_DYRModify.TabIndex = 66;
            this.button_DYRModify.Text = "Modify";
            this.button_DYRModify.UseVisualStyleBackColor = false;
            // 
            // button_DYRAdd
            // 
            this.button_DYRAdd.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_DYRAdd.BackColor = System.Drawing.Color.White;
            this.button_DYRAdd.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_DYRAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_DYRAdd.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_DYRAdd.ForeColor = System.Drawing.Color.Black;
            this.button_DYRAdd.Location = new System.Drawing.Point(222, 300);
            this.button_DYRAdd.Name = "button_DYRAdd";
            this.button_DYRAdd.Size = new System.Drawing.Size(93, 37);
            this.button_DYRAdd.TabIndex = 60;
            this.button_DYRAdd.Text = "Add";
            this.button_DYRAdd.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label3.Location = new System.Drawing.Point(166, 356);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 24);
            this.label3.TabIndex = 65;
            this.label3.Text = "%";
            // 
            // textBox4
            // 
            this.textBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox4.Location = new System.Drawing.Point(103, 353);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(55, 32);
            this.textBox4.TabIndex = 64;
            // 
            // label_DYRRate
            // 
            this.label_DYRRate.AutoSize = true;
            this.label_DYRRate.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DYRRate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_DYRRate.Location = new System.Drawing.Point(31, 356);
            this.label_DYRRate.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_DYRRate.Name = "label_DYRRate";
            this.label_DYRRate.Size = new System.Drawing.Size(64, 24);
            this.label_DYRRate.TabIndex = 63;
            this.label_DYRRate.Text = "Rate:";
            // 
            // textBox3
            // 
            this.textBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox3.Location = new System.Drawing.Point(103, 310);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(55, 32);
            this.textBox3.TabIndex = 62;
            // 
            // label_DYRYearNo
            // 
            this.label_DYRYearNo.AutoSize = true;
            this.label_DYRYearNo.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DYRYearNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_DYRYearNo.Location = new System.Drawing.Point(10, 313);
            this.label_DYRYearNo.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_DYRYearNo.Name = "label_DYRYearNo";
            this.label_DYRYearNo.Size = new System.Drawing.Size(85, 24);
            this.label_DYRYearNo.TabIndex = 61;
            this.label_DYRYearNo.Text = "Year #:";
            // 
            // dataGridView_DEPYEARLYRATE
            // 
            this.dataGridView_DEPYEARLYRATE.AllowUserToAddRows = false;
            this.dataGridView_DEPYEARLYRATE.AllowUserToDeleteRows = false;
            this.dataGridView_DEPYEARLYRATE.AllowUserToResizeColumns = false;
            this.dataGridView_DEPYEARLYRATE.AllowUserToResizeRows = false;
            this.dataGridView_DEPYEARLYRATE.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_DEPYEARLYRATE.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_DEPYEARLYRATE.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DepRateID,
            this.DepCardID,
            this.YEARNO,
            this.YEARRATE});
            this.dataGridView_DEPYEARLYRATE.Enabled = false;
            this.dataGridView_DEPYEARLYRATE.Location = new System.Drawing.Point(6, 4);
            this.dataGridView_DEPYEARLYRATE.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.dataGridView_DEPYEARLYRATE.Name = "dataGridView_DEPYEARLYRATE";
            this.dataGridView_DEPYEARLYRATE.RowTemplate.Height = 24;
            this.dataGridView_DEPYEARLYRATE.Size = new System.Drawing.Size(309, 281);
            this.dataGridView_DEPYEARLYRATE.TabIndex = 59;
            // 
            // DepRateID
            // 
            this.DepRateID.HeaderText = "DepRateID";
            this.DepRateID.Name = "DepRateID";
            this.DepRateID.Visible = false;
            // 
            // DepCardID
            // 
            this.DepCardID.HeaderText = "DepCardID";
            this.DepCardID.Name = "DepCardID";
            this.DepCardID.Visible = false;
            // 
            // YEARNO
            // 
            this.YEARNO.HeaderText = "Year #";
            this.YEARNO.Name = "YEARNO";
            // 
            // YEARRATE
            // 
            this.YEARRATE.HeaderText = "Depriciation Rate";
            this.YEARRATE.Name = "YEARRATE";
            // 
            // radioButton_DepSLM
            // 
            this.radioButton_DepSLM.AutoSize = true;
            this.radioButton_DepSLM.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_DepSLM.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.radioButton_DepSLM.Location = new System.Drawing.Point(85, 80);
            this.radioButton_DepSLM.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.radioButton_DepSLM.Name = "radioButton_DepSLM";
            this.radioButton_DepSLM.Size = new System.Drawing.Size(200, 28);
            this.radioButton_DepSLM.TabIndex = 3;
            this.radioButton_DepSLM.TabStop = true;
            this.radioButton_DepSLM.Text = "Single Line Method";
            this.radioButton_DepSLM.UseVisualStyleBackColor = true;
            // 
            // radioButton_DepRBM
            // 
            this.radioButton_DepRBM.AutoSize = true;
            this.radioButton_DepRBM.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_DepRBM.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.radioButton_DepRBM.Location = new System.Drawing.Point(85, 40);
            this.radioButton_DepRBM.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.radioButton_DepRBM.Name = "radioButton_DepRBM";
            this.radioButton_DepRBM.Size = new System.Drawing.Size(260, 28);
            this.radioButton_DepRBM.TabIndex = 2;
            this.radioButton_DepRBM.TabStop = true;
            this.radioButton_DepRBM.Text = "Reducing Balance Method";
            this.radioButton_DepRBM.UseVisualStyleBackColor = true;
            // 
            // button_UploadPic
            // 
            this.button_UploadPic.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_UploadPic.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.button_UploadPic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_UploadPic.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_UploadPic.ForeColor = System.Drawing.Color.White;
            this.button_UploadPic.Location = new System.Drawing.Point(27, 260);
            this.button_UploadPic.Name = "button_UploadPic";
            this.button_UploadPic.Size = new System.Drawing.Size(192, 44);
            this.button_UploadPic.TabIndex = 26;
            this.button_UploadPic.Text = "Upload";
            this.button_UploadPic.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(27, 37);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(192, 214);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label_Life
            // 
            this.label_Life.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_Life.AutoSize = true;
            this.label_Life.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Life.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_Life.Location = new System.Drawing.Point(515, 187);
            this.label_Life.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_Life.Name = "label_Life";
            this.label_Life.Size = new System.Drawing.Size(54, 24);
            this.label_Life.TabIndex = 139;
            this.label_Life.Text = "Life:";
            // 
            // textBox_SalvageVal
            // 
            this.textBox_SalvageVal.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_SalvageVal.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SalvageVal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox_SalvageVal.Location = new System.Drawing.Point(203, 284);
            this.textBox_SalvageVal.Name = "textBox_SalvageVal";
            this.textBox_SalvageVal.ReadOnly = true;
            this.textBox_SalvageVal.Size = new System.Drawing.Size(184, 32);
            this.textBox_SalvageVal.TabIndex = 143;
            // 
            // label_DepSalVal
            // 
            this.label_DepSalVal.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_DepSalVal.AutoSize = true;
            this.label_DepSalVal.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DepSalVal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_DepSalVal.Location = new System.Drawing.Point(31, 284);
            this.label_DepSalVal.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_DepSalVal.Name = "label_DepSalVal";
            this.label_DepSalVal.Size = new System.Drawing.Size(160, 24);
            this.label_DepSalVal.TabIndex = 142;
            this.label_DepSalVal.Text = "Salvage Value:";
            // 
            // comboBoxLife
            // 
            this.comboBoxLife.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxLife.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxLife.Enabled = false;
            this.comboBoxLife.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxLife.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.comboBoxLife.FormattingEnabled = true;
            this.comboBoxLife.Items.AddRange(new object[] {
            "Months",
            "Years"});
            this.comboBoxLife.Location = new System.Drawing.Point(659, 184);
            this.comboBoxLife.Name = "comboBoxLife";
            this.comboBoxLife.Size = new System.Drawing.Size(100, 32);
            this.comboBoxLife.TabIndex = 141;
            // 
            // textBox2
            // 
            this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox2.Location = new System.Drawing.Point(577, 184);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(76, 32);
            this.textBox2.TabIndex = 140;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox1.Location = new System.Drawing.Point(203, 232);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(76, 32);
            this.textBox1.TabIndex = 137;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // groupBox_UploadPicture
            // 
            this.groupBox_UploadPicture.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox_UploadPicture.Controls.Add(this.button_UploadPic);
            this.groupBox_UploadPicture.Controls.Add(this.pictureBox1);
            this.groupBox_UploadPicture.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_UploadPicture.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.groupBox_UploadPicture.Location = new System.Drawing.Point(517, 245);
            this.groupBox_UploadPicture.Name = "groupBox_UploadPicture";
            this.groupBox_UploadPicture.Size = new System.Drawing.Size(242, 314);
            this.groupBox_UploadPicture.TabIndex = 135;
            this.groupBox_UploadPicture.TabStop = false;
            this.groupBox_UploadPicture.Text = "Upload Picture:";
            // 
            // checkBox1
            // 
            this.checkBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.checkBox1.Location = new System.Drawing.Point(790, 76);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(295, 28);
            this.checkBox1.TabIndex = 144;
            this.checkBox1.Text = "Depriciation Yearly Rates:";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker_PurchaseDate
            // 
            this.dateTimePicker_PurchaseDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateTimePicker_PurchaseDate.CalendarForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.dateTimePicker_PurchaseDate.CalendarMonthBackground = System.Drawing.Color.White;
            this.dateTimePicker_PurchaseDate.CalendarTitleBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(255)))));
            this.dateTimePicker_PurchaseDate.CalendarTitleForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(19)))), ((int)(((byte)(0)))));
            this.dateTimePicker_PurchaseDate.CustomFormat = "dd-MMM-yyy";
            this.dateTimePicker_PurchaseDate.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_PurchaseDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_PurchaseDate.Location = new System.Drawing.Point(203, 181);
            this.dateTimePicker_PurchaseDate.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.dateTimePicker_PurchaseDate.Name = "dateTimePicker_PurchaseDate";
            this.dateTimePicker_PurchaseDate.Size = new System.Drawing.Size(288, 32);
            this.dateTimePicker_PurchaseDate.TabIndex = 126;
            // 
            // groupBox_DepMethod
            // 
            this.groupBox_DepMethod.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox_DepMethod.Controls.Add(this.radioButton_DepSLM);
            this.groupBox_DepMethod.Controls.Add(this.radioButton_DepRBM);
            this.groupBox_DepMethod.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_DepMethod.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.groupBox_DepMethod.Location = new System.Drawing.Point(88, 425);
            this.groupBox_DepMethod.Name = "groupBox_DepMethod";
            this.groupBox_DepMethod.Size = new System.Drawing.Size(403, 134);
            this.groupBox_DepMethod.TabIndex = 136;
            this.groupBox_DepMethod.TabStop = false;
            this.groupBox_DepMethod.Text = "Method:";
            // 
            // label_Percent
            // 
            this.label_Percent.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_Percent.AutoSize = true;
            this.label_Percent.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Percent.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_Percent.Location = new System.Drawing.Point(287, 235);
            this.label_Percent.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_Percent.Name = "label_Percent";
            this.label_Percent.Size = new System.Drawing.Size(34, 24);
            this.label_Percent.TabIndex = 138;
            this.label_Percent.Text = "%";
            this.label_Percent.Click += new System.EventHandler(this.label_Percent_Click);
            // 
            // button_ParentHeadChoose
            // 
            this.button_ParentHeadChoose.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_ParentHeadChoose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.button_ParentHeadChoose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ParentHeadChoose.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ParentHeadChoose.ForeColor = System.Drawing.Color.White;
            this.button_ParentHeadChoose.Location = new System.Drawing.Point(609, 77);
            this.button_ParentHeadChoose.Name = "button_ParentHeadChoose";
            this.button_ParentHeadChoose.Size = new System.Drawing.Size(150, 38);
            this.button_ParentHeadChoose.TabIndex = 134;
            this.button_ParentHeadChoose.Text = "Choose";
            this.button_ParentHeadChoose.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_ParentHeadChoose.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label9.Location = new System.Drawing.Point(49, 82);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(142, 24);
            this.label9.TabIndex = 133;
            this.label9.Text = "Parent Head:";
            // 
            // textBoxParentHead
            // 
            this.textBoxParentHead.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxParentHead.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxParentHead.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBoxParentHead.Location = new System.Drawing.Point(203, 82);
            this.textBoxParentHead.Name = "textBoxParentHead";
            this.textBoxParentHead.ReadOnly = true;
            this.textBoxParentHead.Size = new System.Drawing.Size(400, 32);
            this.textBoxParentHead.TabIndex = 132;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label11.Location = new System.Drawing.Point(41, 132);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(149, 24);
            this.label11.TabIndex = 130;
            this.label11.Text = "Account Title:";
            // 
            // textBoxAccountTitle
            // 
            this.textBoxAccountTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxAccountTitle.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAccountTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBoxAccountTitle.Location = new System.Drawing.Point(203, 132);
            this.textBoxAccountTitle.Name = "textBoxAccountTitle";
            this.textBoxAccountTitle.ReadOnly = true;
            this.textBoxAccountTitle.Size = new System.Drawing.Size(556, 32);
            this.textBoxAccountTitle.TabIndex = 129;
            // 
            // label_Dep
            // 
            this.label_Dep.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_Dep.AutoSize = true;
            this.label_Dep.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Dep.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_Dep.Location = new System.Drawing.Point(471, 20);
            this.label_Dep.Name = "label_Dep";
            this.label_Dep.Size = new System.Drawing.Size(288, 29);
            this.label_Dep.TabIndex = 131;
            this.label_Dep.Text = "Depriciation Properties";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label4.Location = new System.Drawing.Point(127, 235);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 24);
            this.label4.TabIndex = 128;
            this.label4.Text = "Rate:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label_DepPurchaseDate
            // 
            this.label_DepPurchaseDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_DepPurchaseDate.AutoSize = true;
            this.label_DepPurchaseDate.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DepPurchaseDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_DepPurchaseDate.Location = new System.Drawing.Point(30, 181);
            this.label_DepPurchaseDate.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_DepPurchaseDate.Name = "label_DepPurchaseDate";
            this.label_DepPurchaseDate.Size = new System.Drawing.Size(163, 24);
            this.label_DepPurchaseDate.TabIndex = 127;
            this.label_DepPurchaseDate.Text = "Purchase Date:";
            // 
            // textBox5
            // 
            this.textBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox5.Location = new System.Drawing.Point(203, 333);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(184, 32);
            this.textBox5.TabIndex = 147;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label1.Location = new System.Drawing.Point(12, 336);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 24);
            this.label1.TabIndex = 146;
            this.label1.Text = "Chassis Number:";
            // 
            // textBox6
            // 
            this.textBox6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox6.Location = new System.Drawing.Point(203, 380);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(184, 32);
            this.textBox6.TabIndex = 149;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label2.Location = new System.Drawing.Point(17, 383);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(173, 24);
            this.label2.TabIndex = 148;
            this.label2.Text = "Engine Number:";
            // 
            // List_Account_Head_Add_Attr_Dep
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1148, 642);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_DepModify);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label_Life);
            this.Controls.Add(this.textBox_SalvageVal);
            this.Controls.Add(this.label_DepSalVal);
            this.Controls.Add(this.comboBoxLife);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.groupBox_UploadPicture);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.dateTimePicker_PurchaseDate);
            this.Controls.Add(this.groupBox_DepMethod);
            this.Controls.Add(this.label_Percent);
            this.Controls.Add(this.button_ParentHeadChoose);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBoxParentHead);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBoxAccountTitle);
            this.Controls.Add(this.label_Dep);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label_DepPurchaseDate);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "List_Account_Head_Add_Attr_Dep";
            this.Text = "Add Vehicle Properties";
            this.Load += new System.EventHandler(this.List_Account_Head_Add_Attr_Dep_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DEPYEARLYRATE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox_UploadPicture.ResumeLayout(false);
            this.groupBox_DepMethod.ResumeLayout(false);
            this.groupBox_DepMethod.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_DepModify;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_DRYRemove;
        private System.Windows.Forms.Button button_DYRModify;
        private System.Windows.Forms.Button button_DYRAdd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label_DYRRate;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label_DYRYearNo;
        private System.Windows.Forms.DataGridView dataGridView_DEPYEARLYRATE;
        private System.Windows.Forms.DataGridViewTextBoxColumn DepRateID;
        private System.Windows.Forms.DataGridViewTextBoxColumn DepCardID;
        private System.Windows.Forms.DataGridViewTextBoxColumn YEARNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn YEARRATE;
        private System.Windows.Forms.RadioButton radioButton_DepSLM;
        private System.Windows.Forms.RadioButton radioButton_DepRBM;
        private System.Windows.Forms.Button button_UploadPic;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label_Life;
        private System.Windows.Forms.TextBox textBox_SalvageVal;
        private System.Windows.Forms.Label label_DepSalVal;
        private System.Windows.Forms.ComboBox comboBoxLife;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox_UploadPicture;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker_PurchaseDate;
        private System.Windows.Forms.GroupBox groupBox_DepMethod;
        private System.Windows.Forms.Label label_Percent;
        private System.Windows.Forms.Button button_ParentHeadChoose;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxParentHead;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxAccountTitle;
        private System.Windows.Forms.Label label_Dep;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label_DepPurchaseDate;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label2;
    }
}