﻿namespace Hisaab_Kitaab
{
    partial class Single_Entry_Book_Modify
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.maskedTextBox_M3 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox_M2 = new System.Windows.Forms.MaskedTextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.maskedTextBox_PVP = new System.Windows.Forms.MaskedTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox1_PVNo = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox_PVTitle = new System.Windows.Forms.TextBox();
            this.textBox_RVTitle = new System.Windows.Forms.TextBox();
            this.maskedTextBox_M1 = new System.Windows.Forms.MaskedTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox_SigDesig2 = new System.Windows.Forms.TextBox();
            this.textBox_SigN2 = new System.Windows.Forms.TextBox();
            this.textBox_SigN3 = new System.Windows.Forms.TextBox();
            this.textBox_SigDesig3 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_SigN1 = new System.Windows.Forms.TextBox();
            this.textBox_SigDesig1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.maskedTextBox_RVP = new System.Windows.Forms.MaskedTextBox();
            this.textBox_RVNo = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button_Save = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_AccCode = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_BookTitle = new System.Windows.Forms.TextBox();
            this.label_BookID = new System.Windows.Forms.Label();
            this.textBox_BookID = new System.Windows.Forms.TextBox();
            this.label_SingleEntryBookAdd = new System.Windows.Forms.Label();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label2.Location = new System.Drawing.Point(3, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(177, 24);
            this.label2.TabIndex = 46;
            this.label2.Text = "Title of Voucher:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label17.Location = new System.Drawing.Point(36, 331);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(334, 24);
            this.label17.TabIndex = 77;
            this.label17.Text = "Properties for Payment Voucher";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label16.Location = new System.Drawing.Point(36, 184);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(322, 24);
            this.label16.TabIndex = 73;
            this.label16.Text = "Properties for Reciept Voucher";
            // 
            // maskedTextBox_M3
            // 
            this.maskedTextBox_M3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.maskedTextBox_M3.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox_M3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.maskedTextBox_M3.Location = new System.Drawing.Point(455, 133);
            this.maskedTextBox_M3.Mask = "0.00";
            this.maskedTextBox_M3.Name = "maskedTextBox_M3";
            this.maskedTextBox_M3.Size = new System.Drawing.Size(80, 22);
            this.maskedTextBox_M3.TabIndex = 62;
            // 
            // maskedTextBox_M2
            // 
            this.maskedTextBox_M2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.maskedTextBox_M2.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox_M2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.maskedTextBox_M2.Location = new System.Drawing.Point(455, 96);
            this.maskedTextBox_M2.Mask = "0.00";
            this.maskedTextBox_M2.Name = "maskedTextBox_M2";
            this.maskedTextBox_M2.Size = new System.Drawing.Size(80, 22);
            this.maskedTextBox_M2.TabIndex = 61;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.maskedTextBox_PVP);
            this.panel4.Controls.Add(this.label18);
            this.panel4.Controls.Add(this.textBox1_PVNo);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.textBox_PVTitle);
            this.panel4.Location = new System.Drawing.Point(40, 368);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(539, 102);
            this.panel4.TabIndex = 76;
            // 
            // maskedTextBox_PVP
            // 
            this.maskedTextBox_PVP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.maskedTextBox_PVP.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox_PVP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.maskedTextBox_PVP.Location = new System.Drawing.Point(198, 15);
            this.maskedTextBox_PVP.Mask = "aaaa-";
            this.maskedTextBox_PVP.Name = "maskedTextBox_PVP";
            this.maskedTextBox_PVP.Size = new System.Drawing.Size(55, 22);
            this.maskedTextBox_PVP.TabIndex = 62;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label18.Location = new System.Drawing.Point(259, 15);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(170, 24);
            this.label18.TabIndex = 50;
            this.label18.Text = "Last Voucher #:";
            // 
            // textBox1_PVNo
            // 
            this.textBox1_PVNo.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1_PVNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox1_PVNo.Location = new System.Drawing.Point(455, 13);
            this.textBox1_PVNo.Name = "textBox1_PVNo";
            this.textBox1_PVNo.Size = new System.Drawing.Size(57, 29);
            this.textBox1_PVNo.TabIndex = 49;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label19.Location = new System.Drawing.Point(15, 15);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(167, 24);
            this.label19.TabIndex = 48;
            this.label19.Text = "Voucher Prefix:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label20.Location = new System.Drawing.Point(3, 58);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(177, 24);
            this.label20.TabIndex = 46;
            this.label20.Text = "Title of Voucher:";
            // 
            // textBox_PVTitle
            // 
            this.textBox_PVTitle.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_PVTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox_PVTitle.Location = new System.Drawing.Point(198, 57);
            this.textBox_PVTitle.Name = "textBox_PVTitle";
            this.textBox_PVTitle.Size = new System.Drawing.Size(314, 29);
            this.textBox_PVTitle.TabIndex = 45;
            // 
            // textBox_RVTitle
            // 
            this.textBox_RVTitle.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_RVTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox_RVTitle.Location = new System.Drawing.Point(198, 57);
            this.textBox_RVTitle.Name = "textBox_RVTitle";
            this.textBox_RVTitle.Size = new System.Drawing.Size(314, 29);
            this.textBox_RVTitle.TabIndex = 45;
            // 
            // maskedTextBox_M1
            // 
            this.maskedTextBox_M1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.maskedTextBox_M1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.maskedTextBox_M1.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox_M1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.maskedTextBox_M1.Location = new System.Drawing.Point(455, 59);
            this.maskedTextBox_M1.Mask = "0.00";
            this.maskedTextBox_M1.Name = "maskedTextBox_M1";
            this.maskedTextBox_M1.Size = new System.Drawing.Size(80, 22);
            this.maskedTextBox_M1.TabIndex = 55;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label14.Location = new System.Drawing.Point(4, 93);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(22, 36);
            this.label14.TabIndex = 54;
            this.label14.Text = "2";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox_SigDesig2
            // 
            this.textBox_SigDesig2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SigDesig2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_SigDesig2.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SigDesig2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox_SigDesig2.Location = new System.Drawing.Point(244, 96);
            this.textBox_SigDesig2.Name = "textBox_SigDesig2";
            this.textBox_SigDesig2.Size = new System.Drawing.Size(204, 22);
            this.textBox_SigDesig2.TabIndex = 56;
            // 
            // textBox_SigN2
            // 
            this.textBox_SigN2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SigN2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_SigN2.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SigN2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox_SigN2.Location = new System.Drawing.Point(33, 96);
            this.textBox_SigN2.Name = "textBox_SigN2";
            this.textBox_SigN2.Size = new System.Drawing.Size(204, 22);
            this.textBox_SigN2.TabIndex = 55;
            // 
            // textBox_SigN3
            // 
            this.textBox_SigN3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SigN3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_SigN3.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SigN3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox_SigN3.Location = new System.Drawing.Point(33, 133);
            this.textBox_SigN3.Name = "textBox_SigN3";
            this.textBox_SigN3.Size = new System.Drawing.Size(204, 22);
            this.textBox_SigN3.TabIndex = 52;
            // 
            // textBox_SigDesig3
            // 
            this.textBox_SigDesig3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SigDesig3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_SigDesig3.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SigDesig3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox_SigDesig3.Location = new System.Drawing.Point(244, 133);
            this.textBox_SigDesig3.Name = "textBox_SigDesig3";
            this.textBox_SigDesig3.Size = new System.Drawing.Size(204, 22);
            this.textBox_SigDesig3.TabIndex = 51;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label12.Location = new System.Drawing.Point(455, 1);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(68, 54);
            this.label12.TabIndex = 46;
            this.label12.Text = "Left Margin:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label11.Location = new System.Drawing.Point(244, 1);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(204, 54);
            this.label11.TabIndex = 45;
            this.label11.Text = "Designation:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label9.Location = new System.Drawing.Point(33, 1);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(204, 54);
            this.label9.TabIndex = 45;
            this.label9.Text = "Signatory Name:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox_SigN1
            // 
            this.textBox_SigN1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SigN1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_SigN1.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SigN1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox_SigN1.Location = new System.Drawing.Point(33, 59);
            this.textBox_SigN1.Name = "textBox_SigN1";
            this.textBox_SigN1.Size = new System.Drawing.Size(204, 22);
            this.textBox_SigN1.TabIndex = 47;
            // 
            // textBox_SigDesig1
            // 
            this.textBox_SigDesig1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SigDesig1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_SigDesig1.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SigDesig1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox_SigDesig1.Location = new System.Drawing.Point(244, 59);
            this.textBox_SigDesig1.Name = "textBox_SigDesig1";
            this.textBox_SigDesig1.Size = new System.Drawing.Size(204, 22);
            this.textBox_SigDesig1.TabIndex = 48;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label13.Location = new System.Drawing.Point(4, 56);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(22, 36);
            this.label13.TabIndex = 54;
            this.label13.Text = "1";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.panel6.Location = new System.Drawing.Point(173, 487);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(405, 2);
            this.panel6.TabIndex = 75;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.panel5.Location = new System.Drawing.Point(362, 344);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(215, 2);
            this.panel5.TabIndex = 74;
            // 
            // maskedTextBox_RVP
            // 
            this.maskedTextBox_RVP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.maskedTextBox_RVP.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox_RVP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.maskedTextBox_RVP.Location = new System.Drawing.Point(198, 15);
            this.maskedTextBox_RVP.Mask = "aaaa-";
            this.maskedTextBox_RVP.Name = "maskedTextBox_RVP";
            this.maskedTextBox_RVP.Size = new System.Drawing.Size(55, 22);
            this.maskedTextBox_RVP.TabIndex = 61;
            // 
            // textBox_RVNo
            // 
            this.textBox_RVNo.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_RVNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox_RVNo.Location = new System.Drawing.Point(455, 13);
            this.textBox_RVNo.Name = "textBox_RVNo";
            this.textBox_RVNo.Size = new System.Drawing.Size(57, 29);
            this.textBox_RVNo.TabIndex = 49;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label15.Location = new System.Drawing.Point(4, 130);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(22, 38);
            this.label15.TabIndex = 57;
            this.label15.Text = "3";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label4.Location = new System.Drawing.Point(259, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(170, 24);
            this.label4.TabIndex = 50;
            this.label4.Text = "Last Voucher #:";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.maskedTextBox_RVP);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.textBox_RVNo);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.textBox_RVTitle);
            this.panel3.Location = new System.Drawing.Point(40, 221);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(539, 102);
            this.panel3.TabIndex = 72;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label3.Location = new System.Drawing.Point(15, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 24);
            this.label3.TabIndex = 48;
            this.label3.Text = "Voucher Prefix:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.panel2.Location = new System.Drawing.Point(362, 197);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(215, 2);
            this.panel2.TabIndex = 71;
            // 
            // button_Save
            // 
            this.button_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.button_Save.FlatAppearance.BorderSize = 0;
            this.button_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Save.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Save.ForeColor = System.Drawing.Color.White;
            this.button_Save.Location = new System.Drawing.Point(238, 699);
            this.button_Save.Margin = new System.Windows.Forms.Padding(4);
            this.button_Save.Name = "button_Save";
            this.button_Save.Size = new System.Drawing.Size(151, 47);
            this.button_Save.TabIndex = 70;
            this.button_Save.Text = "Save";
            this.button_Save.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.30303F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.43735F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.43736F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.82226F));
            this.tableLayoutPanel1.Controls.Add(this.maskedTextBox_M3, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.maskedTextBox_M1, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.maskedTextBox_M2, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.label14, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox_SigDesig2, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox_SigN2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox_SigN3, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox_SigDesig3, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label12, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label11, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label9, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBox_SigN1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox_SigDesig1, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label13, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label15, 0, 3);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.30009F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.30766F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.30766F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.08459F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(539, 169);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label10.Location = new System.Drawing.Point(36, 475);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(131, 24);
            this.label10.TabIndex = 69;
            this.label10.Text = "Signatories:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Location = new System.Drawing.Point(40, 514);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(539, 169);
            this.panel1.TabIndex = 68;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label5.Location = new System.Drawing.Point(299, 87);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(155, 24);
            this.label5.TabIndex = 67;
            this.label5.Text = "Account Code:";
            // 
            // textBox_AccCode
            // 
            this.textBox_AccCode.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_AccCode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox_AccCode.Location = new System.Drawing.Point(472, 86);
            this.textBox_AccCode.Name = "textBox_AccCode";
            this.textBox_AccCode.Size = new System.Drawing.Size(107, 29);
            this.textBox_AccCode.TabIndex = 66;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label1.Location = new System.Drawing.Point(36, 137);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 24);
            this.label1.TabIndex = 65;
            this.label1.Text = "Book Title:";
            // 
            // textBox_BookTitle
            // 
            this.textBox_BookTitle.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_BookTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox_BookTitle.Location = new System.Drawing.Point(173, 136);
            this.textBox_BookTitle.Name = "textBox_BookTitle";
            this.textBox_BookTitle.Size = new System.Drawing.Size(406, 29);
            this.textBox_BookTitle.TabIndex = 64;
            // 
            // label_BookID
            // 
            this.label_BookID.AutoSize = true;
            this.label_BookID.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_BookID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_BookID.Location = new System.Drawing.Point(55, 85);
            this.label_BookID.Name = "label_BookID";
            this.label_BookID.Size = new System.Drawing.Size(98, 24);
            this.label_BookID.TabIndex = 63;
            this.label_BookID.Text = "Book ID:";
            // 
            // textBox_BookID
            // 
            this.textBox_BookID.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_BookID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBox_BookID.Location = new System.Drawing.Point(173, 86);
            this.textBox_BookID.Name = "textBox_BookID";
            this.textBox_BookID.Size = new System.Drawing.Size(112, 29);
            this.textBox_BookID.TabIndex = 62;
            // 
            // label_SingleEntryBookAdd
            // 
            this.label_SingleEntryBookAdd.AutoSize = true;
            this.label_SingleEntryBookAdd.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SingleEntryBookAdd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_SingleEntryBookAdd.Location = new System.Drawing.Point(177, 9);
            this.label_SingleEntryBookAdd.Name = "label_SingleEntryBookAdd";
            this.label_SingleEntryBookAdd.Size = new System.Drawing.Size(312, 29);
            this.label_SingleEntryBookAdd.TabIndex = 61;
            this.label_SingleEntryBookAdd.Text = "Modify Single Entry Book";
            // 
            // Single_Entry_Book_Modify
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(617, 762);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.button_Save);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox_AccCode);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_BookTitle);
            this.Controls.Add(this.label_BookID);
            this.Controls.Add(this.textBox_BookID);
            this.Controls.Add(this.label_SingleEntryBookAdd);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "Single_Entry_Book_Modify";
            this.Text = "Single_Entry_Book_Modify";
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_M3;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_M2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_PVP;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox1_PVNo;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox_PVTitle;
        private System.Windows.Forms.TextBox textBox_RVTitle;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_M1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox_SigDesig2;
        private System.Windows.Forms.TextBox textBox_SigN2;
        private System.Windows.Forms.TextBox textBox_SigN3;
        private System.Windows.Forms.TextBox textBox_SigDesig3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_SigN1;
        private System.Windows.Forms.TextBox textBox_SigDesig1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_RVP;
        private System.Windows.Forms.TextBox textBox_RVNo;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button_Save;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_AccCode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_BookTitle;
        private System.Windows.Forms.Label label_BookID;
        private System.Windows.Forms.TextBox textBox_BookID;
        private System.Windows.Forms.Label label_SingleEntryBookAdd;
    }
}