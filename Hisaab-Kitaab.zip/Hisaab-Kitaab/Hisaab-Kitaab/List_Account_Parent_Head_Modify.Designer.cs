﻿namespace Hisaab_Kitaab
{
    partial class List_Account_Parent_Head_Modify
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label_ParentTitle = new System.Windows.Forms.Label();
            this.label_ParentCode = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button_Modify = new System.Windows.Forms.Button();
            this.textBox_ParentTitle = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButton_IncSt = new System.Windows.Forms.RadioButton();
            this.radioButton_Bs = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox1_ParentCode_lvl1 = new System.Windows.Forms.ComboBox();
            this.label_Hyphen2 = new System.Windows.Forms.Label();
            this.maskedTextBox_ParentCode_lvl4 = new System.Windows.Forms.MaskedTextBox();
            this.label_Hyphen1 = new System.Windows.Forms.Label();
            this.label_Hyphen3 = new System.Windows.Forms.Label();
            this.maskedTextBox_ParentCode_lvl3 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox_ParentCode_lvl2 = new System.Windows.Forms.MaskedTextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_ParentTitle
            // 
            this.label_ParentTitle.AutoSize = true;
            this.label_ParentTitle.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ParentTitle.Location = new System.Drawing.Point(32, 155);
            this.label_ParentTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ParentTitle.Name = "label_ParentTitle";
            this.label_ParentTitle.Size = new System.Drawing.Size(55, 23);
            this.label_ParentTitle.TabIndex = 19;
            this.label_ParentTitle.Text = "Title:";
            // 
            // label_ParentCode
            // 
            this.label_ParentCode.AutoSize = true;
            this.label_ParentCode.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ParentCode.Location = new System.Drawing.Point(26, 95);
            this.label_ParentCode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ParentCode.Name = "label_ParentCode";
            this.label_ParentCode.Size = new System.Drawing.Size(58, 23);
            this.label_ParentCode.TabIndex = 18;
            this.label_ParentCode.Text = "Code:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(178, 32);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 28);
            this.label1.TabIndex = 17;
            this.label1.Text = "Modify Parent Head";
            // 
            // button_Modify
            // 
            this.button_Modify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Modify.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Modify.Location = new System.Drawing.Point(234, 270);
            this.button_Modify.Margin = new System.Windows.Forms.Padding(4);
            this.button_Modify.Name = "button_Modify";
            this.button_Modify.Size = new System.Drawing.Size(100, 37);
            this.button_Modify.TabIndex = 16;
            this.button_Modify.Text = "Modify";
            this.button_Modify.UseVisualStyleBackColor = true;
            this.button_Modify.Click += new System.EventHandler(this.button_Modify_Click);
            // 
            // textBox_ParentTitle
            // 
            this.textBox_ParentTitle.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_ParentTitle.Location = new System.Drawing.Point(98, 150);
            this.textBox_ParentTitle.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_ParentTitle.Name = "textBox_ParentTitle";
            this.textBox_ParentTitle.Size = new System.Drawing.Size(396, 31);
            this.textBox_ParentTitle.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(33, 214);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 23);
            this.label3.TabIndex = 23;
            this.label3.Text = "Type 2:";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radioButton_IncSt);
            this.panel2.Controls.Add(this.radioButton_Bs);
            this.panel2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(113, 204);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(382, 42);
            this.panel2.TabIndex = 22;
            // 
            // radioButton_IncSt
            // 
            this.radioButton_IncSt.AutoSize = true;
            this.radioButton_IncSt.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_IncSt.Location = new System.Drawing.Point(191, 4);
            this.radioButton_IncSt.Name = "radioButton_IncSt";
            this.radioButton_IncSt.Size = new System.Drawing.Size(188, 27);
            this.radioButton_IncSt.TabIndex = 11;
            this.radioButton_IncSt.TabStop = true;
            this.radioButton_IncSt.Text = "Income Statement";
            this.radioButton_IncSt.UseVisualStyleBackColor = true;
            this.radioButton_IncSt.CheckedChanged += new System.EventHandler(this.radioButton_IncSt_CheckedChanged);
            // 
            // radioButton_Bs
            // 
            this.radioButton_Bs.AutoSize = true;
            this.radioButton_Bs.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_Bs.Location = new System.Drawing.Point(21, 6);
            this.radioButton_Bs.Name = "radioButton_Bs";
            this.radioButton_Bs.Size = new System.Drawing.Size(150, 27);
            this.radioButton_Bs.TabIndex = 10;
            this.radioButton_Bs.TabStop = true;
            this.radioButton_Bs.Text = "Balance Sheet";
            this.radioButton_Bs.UseVisualStyleBackColor = true;
            this.radioButton_Bs.CheckedChanged += new System.EventHandler(this.radioButton_Bs_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.comboBox1_ParentCode_lvl1);
            this.panel1.Controls.Add(this.label_Hyphen2);
            this.panel1.Controls.Add(this.maskedTextBox_ParentCode_lvl4);
            this.panel1.Controls.Add(this.label_Hyphen1);
            this.panel1.Controls.Add(this.label_Hyphen3);
            this.panel1.Controls.Add(this.maskedTextBox_ParentCode_lvl3);
            this.panel1.Controls.Add(this.maskedTextBox_ParentCode_lvl2);
            this.panel1.Location = new System.Drawing.Point(98, 95);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(396, 39);
            this.panel1.TabIndex = 24;
            // 
            // comboBox1_ParentCode_lvl1
            // 
            this.comboBox1_ParentCode_lvl1.BackColor = System.Drawing.Color.White;
            this.comboBox1_ParentCode_lvl1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1_ParentCode_lvl1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox1_ParentCode_lvl1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1_ParentCode_lvl1.FormattingEnabled = true;
            this.comboBox1_ParentCode_lvl1.Items.AddRange(new object[] {
            "010",
            "020",
            "030",
            "040",
            "050"});
            this.comboBox1_ParentCode_lvl1.Location = new System.Drawing.Point(3, 2);
            this.comboBox1_ParentCode_lvl1.Name = "comboBox1_ParentCode_lvl1";
            this.comboBox1_ParentCode_lvl1.Size = new System.Drawing.Size(75, 31);
            this.comboBox1_ParentCode_lvl1.TabIndex = 25;
            // 
            // label_Hyphen2
            // 
            this.label_Hyphen2.AutoSize = true;
            this.label_Hyphen2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Hyphen2.Location = new System.Drawing.Point(223, 4);
            this.label_Hyphen2.Name = "label_Hyphen2";
            this.label_Hyphen2.Size = new System.Drawing.Size(17, 23);
            this.label_Hyphen2.TabIndex = 20;
            this.label_Hyphen2.Text = "-";
            // 
            // maskedTextBox_ParentCode_lvl4
            // 
            this.maskedTextBox_ParentCode_lvl4.BackColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox_ParentCode_lvl4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.maskedTextBox_ParentCode_lvl4.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox_ParentCode_lvl4.Location = new System.Drawing.Point(247, 6);
            this.maskedTextBox_ParentCode_lvl4.Margin = new System.Windows.Forms.Padding(4);
            this.maskedTextBox_ParentCode_lvl4.Mask = "000";
            this.maskedTextBox_ParentCode_lvl4.Name = "maskedTextBox_ParentCode_lvl4";
            this.maskedTextBox_ParentCode_lvl4.ReadOnly = true;
            this.maskedTextBox_ParentCode_lvl4.ResetOnSpace = false;
            this.maskedTextBox_ParentCode_lvl4.Size = new System.Drawing.Size(36, 24);
            this.maskedTextBox_ParentCode_lvl4.TabIndex = 20;
            this.maskedTextBox_ParentCode_lvl4.ValidatingType = typeof(int);
            this.maskedTextBox_ParentCode_lvl4.Click += new System.EventHandler(this.maskedTextBox_ParentCode_lvl4_Click);
            this.maskedTextBox_ParentCode_lvl4.Leave += new System.EventHandler(this.maskedTextBox_ParentCode_lvl4_Leave);
            // 
            // label_Hyphen1
            // 
            this.label_Hyphen1.AutoSize = true;
            this.label_Hyphen1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Hyphen1.Location = new System.Drawing.Point(150, 4);
            this.label_Hyphen1.Name = "label_Hyphen1";
            this.label_Hyphen1.Size = new System.Drawing.Size(17, 23);
            this.label_Hyphen1.TabIndex = 18;
            this.label_Hyphen1.Text = "-";
            // 
            // label_Hyphen3
            // 
            this.label_Hyphen3.AutoSize = true;
            this.label_Hyphen3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Hyphen3.Location = new System.Drawing.Point(84, 5);
            this.label_Hyphen3.Name = "label_Hyphen3";
            this.label_Hyphen3.Size = new System.Drawing.Size(17, 23);
            this.label_Hyphen3.TabIndex = 19;
            this.label_Hyphen3.Text = "-";
            // 
            // maskedTextBox_ParentCode_lvl3
            // 
            this.maskedTextBox_ParentCode_lvl3.BackColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox_ParentCode_lvl3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.maskedTextBox_ParentCode_lvl3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox_ParentCode_lvl3.Location = new System.Drawing.Point(180, 5);
            this.maskedTextBox_ParentCode_lvl3.Margin = new System.Windows.Forms.Padding(4);
            this.maskedTextBox_ParentCode_lvl3.Mask = "000";
            this.maskedTextBox_ParentCode_lvl3.Name = "maskedTextBox_ParentCode_lvl3";
            this.maskedTextBox_ParentCode_lvl3.ReadOnly = true;
            this.maskedTextBox_ParentCode_lvl3.ResetOnSpace = false;
            this.maskedTextBox_ParentCode_lvl3.Size = new System.Drawing.Size(36, 24);
            this.maskedTextBox_ParentCode_lvl3.TabIndex = 19;
            this.maskedTextBox_ParentCode_lvl3.ValidatingType = typeof(int);
            this.maskedTextBox_ParentCode_lvl3.Click += new System.EventHandler(this.maskedTextBox_ParentCode_lvl3_Click);
            this.maskedTextBox_ParentCode_lvl3.Leave += new System.EventHandler(this.maskedTextBox_ParentCode_lvl3_Leave);
            // 
            // maskedTextBox_ParentCode_lvl2
            // 
            this.maskedTextBox_ParentCode_lvl2.BackColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox_ParentCode_lvl2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.maskedTextBox_ParentCode_lvl2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox_ParentCode_lvl2.Location = new System.Drawing.Point(107, 5);
            this.maskedTextBox_ParentCode_lvl2.Margin = new System.Windows.Forms.Padding(4);
            this.maskedTextBox_ParentCode_lvl2.Mask = "000";
            this.maskedTextBox_ParentCode_lvl2.Name = "maskedTextBox_ParentCode_lvl2";
            this.maskedTextBox_ParentCode_lvl2.ReadOnly = true;
            this.maskedTextBox_ParentCode_lvl2.ResetOnSpace = false;
            this.maskedTextBox_ParentCode_lvl2.Size = new System.Drawing.Size(36, 24);
            this.maskedTextBox_ParentCode_lvl2.TabIndex = 18;
            this.maskedTextBox_ParentCode_lvl2.ValidatingType = typeof(int);
            this.maskedTextBox_ParentCode_lvl2.Click += new System.EventHandler(this.maskedTextBox_ParentCode_lvl2_Click);
            this.maskedTextBox_ParentCode_lvl2.Leave += new System.EventHandler(this.maskedTextBox_ParentCode_lvl2_Leave);
            this.maskedTextBox_ParentCode_lvl2.MouseHover += new System.EventHandler(this.maskedTextBox_ParentCode_lvl2_MouseHover);
            // 
            // toolTip1
            // 
            this.toolTip1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.toolTip1.OwnerDraw = true;
            this.toolTip1.Draw += new System.Windows.Forms.DrawToolTipEventHandler(this.toolTip1_Draw);
            // 
            // List_Account_Parent_Head_Modify
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(541, 332);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label_ParentTitle);
            this.Controls.Add(this.label_ParentCode);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_Modify);
            this.Controls.Add(this.textBox_ParentTitle);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "List_Account_Parent_Head_Modify";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "List_Account_Parent_Head_Modify";
            this.Load += new System.EventHandler(this.List_Account_Parent_Head_Modify_Load);
            this.Click += new System.EventHandler(this.List_Account_Parent_Head_Modify_Click);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label_ParentTitle;
        private System.Windows.Forms.Label label_ParentCode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_Modify;
        private System.Windows.Forms.TextBox textBox_ParentTitle;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton radioButton_IncSt;
        private System.Windows.Forms.RadioButton radioButton_Bs;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_Hyphen2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_ParentCode_lvl4;
        private System.Windows.Forms.Label label_Hyphen1;
        private System.Windows.Forms.Label label_Hyphen3;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_ParentCode_lvl3;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_ParentCode_lvl2;
        private System.Windows.Forms.ComboBox comboBox1_ParentCode_lvl1;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}