﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hisaab_Kitaab
{
    public partial class List_Inventory_Attributes : Form
    {
        public List_Inventory_Attributes()
        {
            InitializeComponent();
        }

        private void List_Inventory_Attributes_Load(object sender, EventArgs e)
        {

        }
    }
}
