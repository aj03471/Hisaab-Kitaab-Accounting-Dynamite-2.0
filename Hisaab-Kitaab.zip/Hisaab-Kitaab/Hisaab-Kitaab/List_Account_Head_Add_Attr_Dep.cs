﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hisaab_Kitaab
{
    public partial class List_Account_Head_Add_Attr_Dep : Form
    {
        public List_Account_Head_Add_Attr_Dep(string accHeadID)
        {
            InitializeComponent();
        }

        private void List_Account_Head_Add_Attr_Dep_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label_Percent_Click(object sender, EventArgs e)
        {

        }
    }
}
