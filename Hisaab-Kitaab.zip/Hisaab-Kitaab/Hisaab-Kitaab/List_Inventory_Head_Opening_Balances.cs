﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hisaab_Kitaab
{
    public partial class List_Inventory_Head_Opening_Balances : Form
    {
        public List_Inventory_Head_Opening_Balances()
        {
            InitializeComponent();
        }
    }
}
