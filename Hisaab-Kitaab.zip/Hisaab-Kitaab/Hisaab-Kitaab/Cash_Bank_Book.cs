﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hisaab_Kitaab
{
    public partial class Cash_Bank_Book : Form
    {
        public Cash_Bank_Book()
        {
            InitializeComponent();
        }
    }
}
