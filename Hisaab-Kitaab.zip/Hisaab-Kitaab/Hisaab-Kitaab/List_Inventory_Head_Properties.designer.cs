﻿namespace Hisaab_Kitaab
{
    partial class List_Inventory_Head_Properties
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label12 = new System.Windows.Forms.Label();
            this.Textbox = new System.Windows.Forms.TextBox();
            this.Textbox_ = new System.Windows.Forms.TextBox();
            this.Textbox_PARENT_ID = new System.Windows.Forms.TextBox();
            this.Textbox_INVHEAD_ID = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.richTextBox_INV_SPECIFICATION = new System.Windows.Forms.RichTextBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.Textbox_PRODUCTION_DR_ACC = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.Textbox_CONSUMPTION_DR_ACC = new System.Windows.Forms.TextBox();
            this.Textbox_PURCHASE_DR_ACC = new System.Windows.Forms.TextBox();
            this.Textbox_SALE_CR_ACC = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label_FILHAAAL = new System.Windows.Forms.Label();
            this.button_Modify = new System.Windows.Forms.Button();
            this.button_Remove = new System.Windows.Forms.Button();
            this.button_OK = new System.Windows.Forms.Button();
            this.Textbox_STOCK_UNIT = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Textbox_BALANCE_LOOSE_UNIT = new System.Windows.Forms.TextBox();
            this.Textbox_BALANCE_PACKING_UNIT = new System.Windows.Forms.TextBox();
            this.Textbox_BALANCE_STOCK_UNIT = new System.Windows.Forms.TextBox();
            this.Textbox_COST_STOCK_UNIT = new System.Windows.Forms.TextBox();
            this.Textbox_COST_PACKING_UNIT = new System.Windows.Forms.TextBox();
            this.Textbox_COST_LOOSE_UNIT = new System.Windows.Forms.TextBox();
            this.Textbox_RATE_PRICE_LOOSE_UNIT = new System.Windows.Forms.TextBox();
            this.Textbox_RATE_PRICE_PACKING_UNIT = new System.Windows.Forms.TextBox();
            this.Textbox_RATE_PRICE_STOCK_UNIT = new System.Windows.Forms.TextBox();
            this.Textbox_RATE_PER_LOOSE_UNIT = new System.Windows.Forms.TextBox();
            this.Textbox_RATE_PER_PACKING_UNIT = new System.Windows.Forms.TextBox();
            this.Textbox_RATE_PER_STOCK_UNIT = new System.Windows.Forms.TextBox();
            this.Textbox_LOOSE_UNIT = new System.Windows.Forms.TextBox();
            this.Textbox_PACKING_UNIT = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(35, 419);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(226, 23);
            this.label12.TabIndex = 45;
            this.label12.Text = "Inventory Code/Part No";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // Textbox
            // 
            this.Textbox.Enabled = false;
            this.Textbox.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox.Location = new System.Drawing.Point(355, 467);
            this.Textbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox.Name = "Textbox";
            this.Textbox.Size = new System.Drawing.Size(345, 24);
            this.Textbox.TabIndex = 44;
            // 
            // Textbox_
            // 
            this.Textbox_.Enabled = false;
            this.Textbox_.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_.Location = new System.Drawing.Point(355, 424);
            this.Textbox_.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_.Name = "Textbox_";
            this.Textbox_.Size = new System.Drawing.Size(345, 24);
            this.Textbox_.TabIndex = 42;
            // 
            // Textbox_PARENT_ID
            // 
            this.Textbox_PARENT_ID.Enabled = false;
            this.Textbox_PARENT_ID.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_PARENT_ID.Location = new System.Drawing.Point(355, 373);
            this.Textbox_PARENT_ID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_PARENT_ID.Name = "Textbox_PARENT_ID";
            this.Textbox_PARENT_ID.Size = new System.Drawing.Size(345, 24);
            this.Textbox_PARENT_ID.TabIndex = 41;
            // 
            // Textbox_INVHEAD_ID
            // 
            this.Textbox_INVHEAD_ID.Enabled = false;
            this.Textbox_INVHEAD_ID.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_INVHEAD_ID.Location = new System.Drawing.Point(353, 329);
            this.Textbox_INVHEAD_ID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_INVHEAD_ID.Name = "Textbox_INVHEAD_ID";
            this.Textbox_INVHEAD_ID.Size = new System.Drawing.Size(348, 24);
            this.Textbox_INVHEAD_ID.TabIndex = 40;
            this.Textbox_INVHEAD_ID.TextChanged += new System.EventHandler(this.Textbox_INVHEAD_ID_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(59, 88);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(229, 188);
            this.pictureBox1.TabIndex = 39;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(35, 462);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 23);
            this.label3.TabIndex = 38;
            this.label3.Text = "Storage Location";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(35, 373);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 23);
            this.label2.TabIndex = 37;
            this.label2.Text = "Parent Head";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(35, 333);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 23);
            this.label1.TabIndex = 36;
            this.label1.Text = "Inventory ID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // richTextBox_INV_SPECIFICATION
            // 
            this.richTextBox_INV_SPECIFICATION.Enabled = false;
            this.richTextBox_INV_SPECIFICATION.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox_INV_SPECIFICATION.Location = new System.Drawing.Point(1019, 44);
            this.richTextBox_INV_SPECIFICATION.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.richTextBox_INV_SPECIFICATION.Name = "richTextBox_INV_SPECIFICATION";
            this.richTextBox_INV_SPECIFICATION.Size = new System.Drawing.Size(316, 209);
            this.richTextBox_INV_SPECIFICATION.TabIndex = 71;
            this.richTextBox_INV_SPECIFICATION.Text = "";
            this.richTextBox_INV_SPECIFICATION.TextChanged += new System.EventHandler(this.richTextBox_INV_SPECIFICATION_TextChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(1051, 8);
            this.checkBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(158, 27);
            this.checkBox2.TabIndex = 47;
            this.checkBox2.Text = "Specifications";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(101, 291);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(132, 37);
            this.button1.TabIndex = 73;
            this.button1.Text = "Upload Image";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.Textbox_PRODUCTION_DR_ACC);
            this.panel1.Controls.Add(this.textBox20);
            this.panel1.Controls.Add(this.textBox21);
            this.panel1.Controls.Add(this.textBox22);
            this.panel1.Controls.Add(this.Textbox_CONSUMPTION_DR_ACC);
            this.panel1.Controls.Add(this.Textbox_PURCHASE_DR_ACC);
            this.panel1.Controls.Add(this.Textbox_SALE_CR_ACC);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Location = new System.Drawing.Point(10, 504);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1521, 273);
            this.panel1.TabIndex = 74;
            // 
            // button5
            // 
            this.button5.AutoSize = true;
            this.button5.BackColor = System.Drawing.SystemColors.Window;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button5.Location = new System.Drawing.Point(1051, 229);
            this.button5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(171, 40);
            this.button5.TabIndex = 88;
            this.button5.Text = "Choose";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Visible = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.AutoSize = true;
            this.button4.BackColor = System.Drawing.SystemColors.Window;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button4.Location = new System.Drawing.Point(1051, 125);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(171, 40);
            this.button4.TabIndex = 87;
            this.button4.Text = "Choose";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.AutoSize = true;
            this.button3.BackColor = System.Drawing.SystemColors.Window;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button3.Location = new System.Drawing.Point(1051, 177);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(171, 40);
            this.button3.TabIndex = 86;
            this.button3.Text = "Choose";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.AutoSize = true;
            this.button2.BackColor = System.Drawing.SystemColors.Window;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button2.Location = new System.Drawing.Point(1051, 77);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(171, 40);
            this.button2.TabIndex = 85;
            this.button2.Text = "Choose";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(682, 232);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(345, 31);
            this.textBox1.TabIndex = 84;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(17, 227);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(139, 23);
            this.label20.TabIndex = 83;
            this.label20.Text = "Production CR";
            // 
            // Textbox_PRODUCTION_DR_ACC
            // 
            this.Textbox_PRODUCTION_DR_ACC.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Textbox_PRODUCTION_DR_ACC.Enabled = false;
            this.Textbox_PRODUCTION_DR_ACC.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_PRODUCTION_DR_ACC.Location = new System.Drawing.Point(319, 229);
            this.Textbox_PRODUCTION_DR_ACC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_PRODUCTION_DR_ACC.Name = "Textbox_PRODUCTION_DR_ACC";
            this.Textbox_PRODUCTION_DR_ACC.Size = new System.Drawing.Size(345, 31);
            this.Textbox_PRODUCTION_DR_ACC.TabIndex = 82;
            // 
            // textBox20
            // 
            this.textBox20.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox20.Enabled = false;
            this.textBox20.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox20.Location = new System.Drawing.Point(683, 177);
            this.textBox20.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(345, 31);
            this.textBox20.TabIndex = 81;
            // 
            // textBox21
            // 
            this.textBox21.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox21.Enabled = false;
            this.textBox21.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox21.Location = new System.Drawing.Point(682, 125);
            this.textBox21.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(345, 31);
            this.textBox21.TabIndex = 80;
            // 
            // textBox22
            // 
            this.textBox22.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox22.Enabled = false;
            this.textBox22.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox22.Location = new System.Drawing.Point(682, 77);
            this.textBox22.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(345, 31);
            this.textBox22.TabIndex = 79;
            this.textBox22.TextChanged += new System.EventHandler(this.textBox22_TextChanged);
            // 
            // Textbox_CONSUMPTION_DR_ACC
            // 
            this.Textbox_CONSUMPTION_DR_ACC.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Textbox_CONSUMPTION_DR_ACC.Enabled = false;
            this.Textbox_CONSUMPTION_DR_ACC.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_CONSUMPTION_DR_ACC.Location = new System.Drawing.Point(319, 177);
            this.Textbox_CONSUMPTION_DR_ACC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_CONSUMPTION_DR_ACC.Name = "Textbox_CONSUMPTION_DR_ACC";
            this.Textbox_CONSUMPTION_DR_ACC.Size = new System.Drawing.Size(345, 31);
            this.Textbox_CONSUMPTION_DR_ACC.TabIndex = 78;
            this.Textbox_CONSUMPTION_DR_ACC.TextChanged += new System.EventHandler(this.Textbox_CONSUMPTION_DR_ACC_TextChanged);
            // 
            // Textbox_PURCHASE_DR_ACC
            // 
            this.Textbox_PURCHASE_DR_ACC.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Textbox_PURCHASE_DR_ACC.Enabled = false;
            this.Textbox_PURCHASE_DR_ACC.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_PURCHASE_DR_ACC.Location = new System.Drawing.Point(319, 125);
            this.Textbox_PURCHASE_DR_ACC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_PURCHASE_DR_ACC.Name = "Textbox_PURCHASE_DR_ACC";
            this.Textbox_PURCHASE_DR_ACC.Size = new System.Drawing.Size(345, 31);
            this.Textbox_PURCHASE_DR_ACC.TabIndex = 77;
            // 
            // Textbox_SALE_CR_ACC
            // 
            this.Textbox_SALE_CR_ACC.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Textbox_SALE_CR_ACC.Enabled = false;
            this.Textbox_SALE_CR_ACC.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_SALE_CR_ACC.Location = new System.Drawing.Point(319, 77);
            this.Textbox_SALE_CR_ACC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_SALE_CR_ACC.Name = "Textbox_SALE_CR_ACC";
            this.Textbox_SALE_CR_ACC.Size = new System.Drawing.Size(345, 31);
            this.Textbox_SALE_CR_ACC.TabIndex = 76;
            this.Textbox_SALE_CR_ACC.TextChanged += new System.EventHandler(this.Textbox_SALE_CR_ACC_TextChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(17, 177);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(162, 23);
            this.label18.TabIndex = 55;
            this.label18.Text = "Consumption DR";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(17, 124);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(224, 23);
            this.label17.TabIndex = 54;
            this.label17.Text = "Purchase DR/Return Cr";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(17, 68);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(186, 23);
            this.label16.TabIndex = 53;
            this.label16.Text = "Sales CR/Return Dr";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(717, 13);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(242, 28);
            this.label15.TabIndex = 52;
            this.label15.Text = "Account Parent Head";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(411, 13);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(131, 28);
            this.label14.TabIndex = 51;
            this.label14.Text = "Account ID";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(17, 13);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(269, 28);
            this.label13.TabIndex = 50;
            this.label13.Text = "Accounts to be Affected";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(567, 23);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(305, 28);
            this.label19.TabIndex = 75;
            this.label19.Text = "Inventory Head Properties";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(59, 49);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(118, 27);
            this.checkBox1.TabIndex = 43;
            this.checkBox1.Text = "Filename";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label_FILHAAAL
            // 
            this.label_FILHAAAL.AutoSize = true;
            this.label_FILHAAAL.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_FILHAAAL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_FILHAAAL.Location = new System.Drawing.Point(677, 88);
            this.label_FILHAAAL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_FILHAAAL.Name = "label_FILHAAAL";
            this.label_FILHAAAL.Size = new System.Drawing.Size(124, 28);
            this.label_FILHAAAL.TabIndex = 76;
            this.label_FILHAAAL.Text = "FILHAAAL";
            this.label_FILHAAAL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // button_Modify
            // 
            this.button_Modify.BackColor = System.Drawing.SystemColors.Window;
            this.button_Modify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Modify.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Modify.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button_Modify.Location = new System.Drawing.Point(1161, 792);
            this.button_Modify.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_Modify.Name = "button_Modify";
            this.button_Modify.Size = new System.Drawing.Size(171, 47);
            this.button_Modify.TabIndex = 77;
            this.button_Modify.Text = "Modify";
            this.button_Modify.UseVisualStyleBackColor = false;
            this.button_Modify.Click += new System.EventHandler(this.button_Modify_Click_1);
            // 
            // button_Remove
            // 
            this.button_Remove.BackColor = System.Drawing.SystemColors.Window;
            this.button_Remove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Remove.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Remove.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button_Remove.Location = new System.Drawing.Point(975, 792);
            this.button_Remove.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_Remove.Name = "button_Remove";
            this.button_Remove.Size = new System.Drawing.Size(171, 47);
            this.button_Remove.TabIndex = 78;
            this.button_Remove.Text = "Remove";
            this.button_Remove.UseVisualStyleBackColor = false;
            this.button_Remove.Click += new System.EventHandler(this.button_Remove_Click);
            // 
            // button_OK
            // 
            this.button_OK.BackColor = System.Drawing.SystemColors.Window;
            this.button_OK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_OK.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_OK.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button_OK.Location = new System.Drawing.Point(1351, 792);
            this.button_OK.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_OK.Name = "button_OK";
            this.button_OK.Size = new System.Drawing.Size(171, 47);
            this.button_OK.TabIndex = 79;
            this.button_OK.Text = "OK";
            this.button_OK.UseVisualStyleBackColor = false;
            this.button_OK.Visible = false;
            this.button_OK.Click += new System.EventHandler(this.button_OK_Click);
            // 
            // Textbox_STOCK_UNIT
            // 
            this.Textbox_STOCK_UNIT.Enabled = false;
            this.Textbox_STOCK_UNIT.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_STOCK_UNIT.Location = new System.Drawing.Point(946, 325);
            this.Textbox_STOCK_UNIT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_STOCK_UNIT.Name = "Textbox_STOCK_UNIT";
            this.Textbox_STOCK_UNIT.Size = new System.Drawing.Size(157, 24);
            this.Textbox_STOCK_UNIT.TabIndex = 103;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(1415, 275);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 23);
            this.label11.TabIndex = 102;
            this.label11.Text = "Unit 3";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(1197, 275);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 23);
            this.label10.TabIndex = 101;
            this.label10.Text = "Unit 2";
            // 
            // Textbox_BALANCE_LOOSE_UNIT
            // 
            this.Textbox_BALANCE_LOOSE_UNIT.Enabled = false;
            this.Textbox_BALANCE_LOOSE_UNIT.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_BALANCE_LOOSE_UNIT.Location = new System.Drawing.Point(1377, 463);
            this.Textbox_BALANCE_LOOSE_UNIT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_BALANCE_LOOSE_UNIT.Name = "Textbox_BALANCE_LOOSE_UNIT";
            this.Textbox_BALANCE_LOOSE_UNIT.Size = new System.Drawing.Size(156, 24);
            this.Textbox_BALANCE_LOOSE_UNIT.TabIndex = 100;
            // 
            // Textbox_BALANCE_PACKING_UNIT
            // 
            this.Textbox_BALANCE_PACKING_UNIT.Enabled = false;
            this.Textbox_BALANCE_PACKING_UNIT.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_BALANCE_PACKING_UNIT.Location = new System.Drawing.Point(1161, 465);
            this.Textbox_BALANCE_PACKING_UNIT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_BALANCE_PACKING_UNIT.Name = "Textbox_BALANCE_PACKING_UNIT";
            this.Textbox_BALANCE_PACKING_UNIT.Size = new System.Drawing.Size(152, 24);
            this.Textbox_BALANCE_PACKING_UNIT.TabIndex = 99;
            // 
            // Textbox_BALANCE_STOCK_UNIT
            // 
            this.Textbox_BALANCE_STOCK_UNIT.Enabled = false;
            this.Textbox_BALANCE_STOCK_UNIT.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_BALANCE_STOCK_UNIT.Location = new System.Drawing.Point(946, 465);
            this.Textbox_BALANCE_STOCK_UNIT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_BALANCE_STOCK_UNIT.Name = "Textbox_BALANCE_STOCK_UNIT";
            this.Textbox_BALANCE_STOCK_UNIT.Size = new System.Drawing.Size(157, 24);
            this.Textbox_BALANCE_STOCK_UNIT.TabIndex = 98;
            // 
            // Textbox_COST_STOCK_UNIT
            // 
            this.Textbox_COST_STOCK_UNIT.Enabled = false;
            this.Textbox_COST_STOCK_UNIT.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_COST_STOCK_UNIT.Location = new System.Drawing.Point(946, 433);
            this.Textbox_COST_STOCK_UNIT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_COST_STOCK_UNIT.Name = "Textbox_COST_STOCK_UNIT";
            this.Textbox_COST_STOCK_UNIT.Size = new System.Drawing.Size(157, 24);
            this.Textbox_COST_STOCK_UNIT.TabIndex = 97;
            // 
            // Textbox_COST_PACKING_UNIT
            // 
            this.Textbox_COST_PACKING_UNIT.Enabled = false;
            this.Textbox_COST_PACKING_UNIT.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_COST_PACKING_UNIT.Location = new System.Drawing.Point(1161, 433);
            this.Textbox_COST_PACKING_UNIT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_COST_PACKING_UNIT.Name = "Textbox_COST_PACKING_UNIT";
            this.Textbox_COST_PACKING_UNIT.Size = new System.Drawing.Size(152, 24);
            this.Textbox_COST_PACKING_UNIT.TabIndex = 96;
            // 
            // Textbox_COST_LOOSE_UNIT
            // 
            this.Textbox_COST_LOOSE_UNIT.Enabled = false;
            this.Textbox_COST_LOOSE_UNIT.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_COST_LOOSE_UNIT.Location = new System.Drawing.Point(1377, 428);
            this.Textbox_COST_LOOSE_UNIT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_COST_LOOSE_UNIT.Name = "Textbox_COST_LOOSE_UNIT";
            this.Textbox_COST_LOOSE_UNIT.Size = new System.Drawing.Size(156, 24);
            this.Textbox_COST_LOOSE_UNIT.TabIndex = 95;
            // 
            // Textbox_RATE_PRICE_LOOSE_UNIT
            // 
            this.Textbox_RATE_PRICE_LOOSE_UNIT.Enabled = false;
            this.Textbox_RATE_PRICE_LOOSE_UNIT.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_RATE_PRICE_LOOSE_UNIT.Location = new System.Drawing.Point(1377, 396);
            this.Textbox_RATE_PRICE_LOOSE_UNIT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_RATE_PRICE_LOOSE_UNIT.Name = "Textbox_RATE_PRICE_LOOSE_UNIT";
            this.Textbox_RATE_PRICE_LOOSE_UNIT.Size = new System.Drawing.Size(156, 24);
            this.Textbox_RATE_PRICE_LOOSE_UNIT.TabIndex = 94;
            // 
            // Textbox_RATE_PRICE_PACKING_UNIT
            // 
            this.Textbox_RATE_PRICE_PACKING_UNIT.Enabled = false;
            this.Textbox_RATE_PRICE_PACKING_UNIT.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_RATE_PRICE_PACKING_UNIT.Location = new System.Drawing.Point(1161, 396);
            this.Textbox_RATE_PRICE_PACKING_UNIT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_RATE_PRICE_PACKING_UNIT.Name = "Textbox_RATE_PRICE_PACKING_UNIT";
            this.Textbox_RATE_PRICE_PACKING_UNIT.Size = new System.Drawing.Size(152, 24);
            this.Textbox_RATE_PRICE_PACKING_UNIT.TabIndex = 93;
            // 
            // Textbox_RATE_PRICE_STOCK_UNIT
            // 
            this.Textbox_RATE_PRICE_STOCK_UNIT.Enabled = false;
            this.Textbox_RATE_PRICE_STOCK_UNIT.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_RATE_PRICE_STOCK_UNIT.Location = new System.Drawing.Point(946, 396);
            this.Textbox_RATE_PRICE_STOCK_UNIT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_RATE_PRICE_STOCK_UNIT.Name = "Textbox_RATE_PRICE_STOCK_UNIT";
            this.Textbox_RATE_PRICE_STOCK_UNIT.Size = new System.Drawing.Size(157, 24);
            this.Textbox_RATE_PRICE_STOCK_UNIT.TabIndex = 92;
            // 
            // Textbox_RATE_PER_LOOSE_UNIT
            // 
            this.Textbox_RATE_PER_LOOSE_UNIT.Enabled = false;
            this.Textbox_RATE_PER_LOOSE_UNIT.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_RATE_PER_LOOSE_UNIT.Location = new System.Drawing.Point(1377, 364);
            this.Textbox_RATE_PER_LOOSE_UNIT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_RATE_PER_LOOSE_UNIT.Name = "Textbox_RATE_PER_LOOSE_UNIT";
            this.Textbox_RATE_PER_LOOSE_UNIT.Size = new System.Drawing.Size(156, 24);
            this.Textbox_RATE_PER_LOOSE_UNIT.TabIndex = 91;
            // 
            // Textbox_RATE_PER_PACKING_UNIT
            // 
            this.Textbox_RATE_PER_PACKING_UNIT.Enabled = false;
            this.Textbox_RATE_PER_PACKING_UNIT.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_RATE_PER_PACKING_UNIT.Location = new System.Drawing.Point(1161, 364);
            this.Textbox_RATE_PER_PACKING_UNIT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_RATE_PER_PACKING_UNIT.Name = "Textbox_RATE_PER_PACKING_UNIT";
            this.Textbox_RATE_PER_PACKING_UNIT.Size = new System.Drawing.Size(152, 24);
            this.Textbox_RATE_PER_PACKING_UNIT.TabIndex = 90;
            // 
            // Textbox_RATE_PER_STOCK_UNIT
            // 
            this.Textbox_RATE_PER_STOCK_UNIT.Enabled = false;
            this.Textbox_RATE_PER_STOCK_UNIT.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_RATE_PER_STOCK_UNIT.Location = new System.Drawing.Point(946, 364);
            this.Textbox_RATE_PER_STOCK_UNIT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_RATE_PER_STOCK_UNIT.Name = "Textbox_RATE_PER_STOCK_UNIT";
            this.Textbox_RATE_PER_STOCK_UNIT.Size = new System.Drawing.Size(157, 24);
            this.Textbox_RATE_PER_STOCK_UNIT.TabIndex = 89;
            // 
            // Textbox_LOOSE_UNIT
            // 
            this.Textbox_LOOSE_UNIT.Enabled = false;
            this.Textbox_LOOSE_UNIT.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_LOOSE_UNIT.Location = new System.Drawing.Point(1377, 330);
            this.Textbox_LOOSE_UNIT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_LOOSE_UNIT.Name = "Textbox_LOOSE_UNIT";
            this.Textbox_LOOSE_UNIT.Size = new System.Drawing.Size(156, 24);
            this.Textbox_LOOSE_UNIT.TabIndex = 88;
            // 
            // Textbox_PACKING_UNIT
            // 
            this.Textbox_PACKING_UNIT.Enabled = false;
            this.Textbox_PACKING_UNIT.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_PACKING_UNIT.Location = new System.Drawing.Point(1161, 330);
            this.Textbox_PACKING_UNIT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Textbox_PACKING_UNIT.Name = "Textbox_PACKING_UNIT";
            this.Textbox_PACKING_UNIT.Size = new System.Drawing.Size(152, 24);
            this.Textbox_PACKING_UNIT.TabIndex = 87;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(985, 275);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 23);
            this.label9.TabIndex = 86;
            this.label9.Text = "Unit 1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label8.Location = new System.Drawing.Point(729, 325);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 23);
            this.label8.TabIndex = 85;
            this.label8.Text = "Define Unit";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(730, 396);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 23);
            this.label7.TabIndex = 84;
            this.label7.Text = "Retail Price";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(729, 360);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 23);
            this.label6.TabIndex = 83;
            this.label6.Text = "Rate/Unit";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(731, 433);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 23);
            this.label5.TabIndex = 82;
            this.label5.Text = "Cost/Unit";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(733, 465);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 23);
            this.label4.TabIndex = 81;
            this.label4.Text = "Balance Stock";
            // 
            // List_Inventory_Head_Properties
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.Textbox_STOCK_UNIT);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Textbox_BALANCE_LOOSE_UNIT);
            this.Controls.Add(this.Textbox_BALANCE_PACKING_UNIT);
            this.Controls.Add(this.Textbox_BALANCE_STOCK_UNIT);
            this.Controls.Add(this.Textbox_COST_STOCK_UNIT);
            this.Controls.Add(this.Textbox_COST_PACKING_UNIT);
            this.Controls.Add(this.Textbox_COST_LOOSE_UNIT);
            this.Controls.Add(this.Textbox_RATE_PRICE_LOOSE_UNIT);
            this.Controls.Add(this.Textbox_RATE_PRICE_PACKING_UNIT);
            this.Controls.Add(this.Textbox_RATE_PRICE_STOCK_UNIT);
            this.Controls.Add(this.Textbox_RATE_PER_LOOSE_UNIT);
            this.Controls.Add(this.Textbox_RATE_PER_PACKING_UNIT);
            this.Controls.Add(this.Textbox_RATE_PER_STOCK_UNIT);
            this.Controls.Add(this.Textbox_LOOSE_UNIT);
            this.Controls.Add(this.Textbox_PACKING_UNIT);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button_OK);
            this.Controls.Add(this.button_Remove);
            this.Controls.Add(this.button_Modify);
            this.Controls.Add(this.label_FILHAAAL);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.richTextBox_INV_SPECIFICATION);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.Textbox);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.Textbox_);
            this.Controls.Add(this.Textbox_PARENT_ID);
            this.Controls.Add(this.Textbox_INVHEAD_ID);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "List_Inventory_Head_Properties";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "List_Inventory_Head_Properties";
            this.Load += new System.EventHandler(this.List_Inventory_Head_Properties_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label20;
        public System.Windows.Forms.Button button_Modify;
        public System.Windows.Forms.Button button_Remove;
        public System.Windows.Forms.Button button_OK;
        public System.Windows.Forms.Button button5;
        public System.Windows.Forms.Button button4;
        public System.Windows.Forms.Button button3;
        public System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox Textbox_SALE_CR_ACC;
        public System.Windows.Forms.TextBox Textbox;
        public System.Windows.Forms.TextBox Textbox_;
        public System.Windows.Forms.TextBox Textbox_PARENT_ID;
        public System.Windows.Forms.TextBox Textbox_INVHEAD_ID;
        public System.Windows.Forms.TextBox textBox20;
        public System.Windows.Forms.TextBox textBox21;
        public System.Windows.Forms.TextBox textBox22;
        public System.Windows.Forms.TextBox Textbox_CONSUMPTION_DR_ACC;
        public System.Windows.Forms.TextBox Textbox_PURCHASE_DR_ACC;
        public System.Windows.Forms.TextBox Textbox_PRODUCTION_DR_ACC;
        public System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.TextBox Textbox_STOCK_UNIT;
        public System.Windows.Forms.TextBox Textbox_BALANCE_LOOSE_UNIT;
        public System.Windows.Forms.TextBox Textbox_BALANCE_PACKING_UNIT;
        public System.Windows.Forms.TextBox Textbox_BALANCE_STOCK_UNIT;
        public System.Windows.Forms.TextBox Textbox_COST_STOCK_UNIT;
        public System.Windows.Forms.TextBox Textbox_COST_PACKING_UNIT;
        public System.Windows.Forms.TextBox Textbox_COST_LOOSE_UNIT;
        public System.Windows.Forms.TextBox Textbox_RATE_PRICE_LOOSE_UNIT;
        public System.Windows.Forms.TextBox Textbox_RATE_PRICE_PACKING_UNIT;
        public System.Windows.Forms.TextBox Textbox_RATE_PRICE_STOCK_UNIT;
        public System.Windows.Forms.TextBox Textbox_RATE_PER_LOOSE_UNIT;
        public System.Windows.Forms.TextBox Textbox_RATE_PER_PACKING_UNIT;
        public System.Windows.Forms.TextBox Textbox_RATE_PER_STOCK_UNIT;
        public System.Windows.Forms.TextBox Textbox_LOOSE_UNIT;
        public System.Windows.Forms.TextBox Textbox_PACKING_UNIT;
        public System.Windows.Forms.RichTextBox richTextBox_INV_SPECIFICATION;
        public System.Windows.Forms.Label label_FILHAAAL;
    }
}