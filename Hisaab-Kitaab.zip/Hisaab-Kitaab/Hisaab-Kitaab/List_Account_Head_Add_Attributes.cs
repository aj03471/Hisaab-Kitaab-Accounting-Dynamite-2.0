﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hisaab_Kitaab
{
    public partial class List_Account_Head_Add_Attributes : Form
    {
        public List_Account_Head_Add_Attributes( string accHeadID)
        {
            InitializeComponent();
            
        }

        private void List_Account_Head_Add_Attributes_Load(object sender, EventArgs e)
        {

        }
    }
}
