﻿namespace Hisaab_Kitaab
{
    partial class Choose_Account_Parent_Head
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_AccParentHead = new System.Windows.Forms.Label();
            this.tab_BalSheet = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.treeView_BSAccHead = new System.Windows.Forms.TreeView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.treeView_IncAccHead = new System.Windows.Forms.TreeView();
            this.Button_Ok = new System.Windows.Forms.Button();
            this.tab_BalSheet.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_AccParentHead
            // 
            this.label_AccParentHead.AutoSize = true;
            this.label_AccParentHead.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_AccParentHead.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_AccParentHead.Location = new System.Drawing.Point(276, 30);
            this.label_AccParentHead.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_AccParentHead.Name = "label_AccParentHead";
            this.label_AccParentHead.Size = new System.Drawing.Size(253, 29);
            this.label_AccParentHead.TabIndex = 33;
            this.label_AccParentHead.Text = "List of Parent Heads";
            // 
            // tab_BalSheet
            // 
            this.tab_BalSheet.Controls.Add(this.tabPage1);
            this.tab_BalSheet.Controls.Add(this.tabPage2);
            this.tab_BalSheet.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab_BalSheet.Location = new System.Drawing.Point(28, 87);
            this.tab_BalSheet.Margin = new System.Windows.Forms.Padding(4);
            this.tab_BalSheet.Name = "tab_BalSheet";
            this.tab_BalSheet.SelectedIndex = 0;
            this.tab_BalSheet.Size = new System.Drawing.Size(751, 538);
            this.tab_BalSheet.TabIndex = 32;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.treeView_BSAccHead);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.tabPage1.Location = new System.Drawing.Point(4, 33);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(743, 501);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Balance Sheet";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // treeView_BSAccHead
            // 
            this.treeView_BSAccHead.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treeView_BSAccHead.Location = new System.Drawing.Point(8, 7);
            this.treeView_BSAccHead.Margin = new System.Windows.Forms.Padding(4);
            this.treeView_BSAccHead.Name = "treeView_BSAccHead";
            this.treeView_BSAccHead.Size = new System.Drawing.Size(723, 483);
            this.treeView_BSAccHead.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.treeView_IncAccHead);
            this.tabPage2.Location = new System.Drawing.Point(4, 33);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(743, 501);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Income Statement";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // treeView_IncAccHead
            // 
            this.treeView_IncAccHead.Location = new System.Drawing.Point(8, 7);
            this.treeView_IncAccHead.Margin = new System.Windows.Forms.Padding(4);
            this.treeView_IncAccHead.Name = "treeView_IncAccHead";
            this.treeView_IncAccHead.Size = new System.Drawing.Size(723, 483);
            this.treeView_IncAccHead.TabIndex = 1;
            // 
            // Button_Ok
            // 
            this.Button_Ok.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.Button_Ok.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button_Ok.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Ok.ForeColor = System.Drawing.Color.White;
            this.Button_Ok.Location = new System.Drawing.Point(310, 646);
            this.Button_Ok.Margin = new System.Windows.Forms.Padding(4);
            this.Button_Ok.Name = "Button_Ok";
            this.Button_Ok.Size = new System.Drawing.Size(171, 47);
            this.Button_Ok.TabIndex = 25;
            this.Button_Ok.Text = "OK";
            this.Button_Ok.UseVisualStyleBackColor = false;
            this.Button_Ok.Click += new System.EventHandler(this.Button_Ok_Click);
            // 
            // Choose_Account_Parent_Head
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(811, 732);
            this.Controls.Add(this.label_AccParentHead);
            this.Controls.Add(this.tab_BalSheet);
            this.Controls.Add(this.Button_Ok);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Choose_Account_Parent_Head";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "List_Account_Attributes_Choose";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Choose_Account_Parent_Head_FormClosed);
            this.Load += new System.EventHandler(this.List_Account_Attributes_Choose_Load);
            this.tab_BalSheet.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_AccParentHead;
        private System.Windows.Forms.TabControl tab_BalSheet;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TreeView treeView_BSAccHead;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TreeView treeView_IncAccHead;
        private System.Windows.Forms.Button Button_Ok;
    }
}