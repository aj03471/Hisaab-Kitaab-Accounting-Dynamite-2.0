﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hisaab_Kitaab
{
    public partial class Add_Single_Entry_Transactions : Form
    {
        public Add_Single_Entry_Transactions()
        {
            InitializeComponent();
        }
    }
}
