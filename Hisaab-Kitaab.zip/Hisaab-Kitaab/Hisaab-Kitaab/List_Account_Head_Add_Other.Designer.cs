﻿namespace Hisaab_Kitaab
{
    partial class List_Account_Head_Add_Other
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(List_Account_Head_Add_Other));
            this.button_ParentHeadChoose = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxParentHead = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxAccountTitle = new System.Windows.Forms.TextBox();
            this.label_Dep = new System.Windows.Forms.Label();
            this.button_DepModify = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_ParentHeadChoose
            // 
            this.button_ParentHeadChoose.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_ParentHeadChoose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.button_ParentHeadChoose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ParentHeadChoose.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ParentHeadChoose.ForeColor = System.Drawing.Color.White;
            this.button_ParentHeadChoose.Location = new System.Drawing.Point(584, 79);
            this.button_ParentHeadChoose.Name = "button_ParentHeadChoose";
            this.button_ParentHeadChoose.Size = new System.Drawing.Size(150, 38);
            this.button_ParentHeadChoose.TabIndex = 119;
            this.button_ParentHeadChoose.Text = "Choose";
            this.button_ParentHeadChoose.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_ParentHeadChoose.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label9.Location = new System.Drawing.Point(24, 84);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(142, 24);
            this.label9.TabIndex = 118;
            this.label9.Text = "Parent Head:";
            // 
            // textBoxParentHead
            // 
            this.textBoxParentHead.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxParentHead.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxParentHead.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBoxParentHead.Location = new System.Drawing.Point(194, 84);
            this.textBoxParentHead.Name = "textBoxParentHead";
            this.textBoxParentHead.ReadOnly = true;
            this.textBoxParentHead.Size = new System.Drawing.Size(384, 32);
            this.textBoxParentHead.TabIndex = 117;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label11.Location = new System.Drawing.Point(16, 134);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(149, 24);
            this.label11.TabIndex = 115;
            this.label11.Text = "Account Title:";
            // 
            // textBoxAccountTitle
            // 
            this.textBoxAccountTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxAccountTitle.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAccountTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.textBoxAccountTitle.Location = new System.Drawing.Point(194, 134);
            this.textBoxAccountTitle.Name = "textBoxAccountTitle";
            this.textBoxAccountTitle.ReadOnly = true;
            this.textBoxAccountTitle.Size = new System.Drawing.Size(540, 32);
            this.textBoxAccountTitle.TabIndex = 114;
            // 
            // label_Dep
            // 
            this.label_Dep.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_Dep.AutoSize = true;
            this.label_Dep.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Dep.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_Dep.Location = new System.Drawing.Point(246, 26);
            this.label_Dep.Name = "label_Dep";
            this.label_Dep.Size = new System.Drawing.Size(278, 29);
            this.label_Dep.TabIndex = 116;
            this.label_Dep.Text = "Modify Account Heads";
            // 
            // button_DepModify
            // 
            this.button_DepModify.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_DepModify.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.button_DepModify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_DepModify.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_DepModify.ForeColor = System.Drawing.Color.White;
            this.button_DepModify.Location = new System.Drawing.Point(277, 188);
            this.button_DepModify.Name = "button_DepModify";
            this.button_DepModify.Size = new System.Drawing.Size(192, 44);
            this.button_DepModify.TabIndex = 120;
            this.button_DepModify.Text = "Modify";
            this.button_DepModify.UseVisualStyleBackColor = false;
            // 
            // List_Account_Head_Add_Other
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(749, 256);
            this.Controls.Add(this.button_DepModify);
            this.Controls.Add(this.button_ParentHeadChoose);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBoxParentHead);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBoxAccountTitle);
            this.Controls.Add(this.label_Dep);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "List_Account_Head_Add_Other";
            this.Text = "Modify Account Head Properties";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_ParentHeadChoose;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxParentHead;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxAccountTitle;
        private System.Windows.Forms.Label label_Dep;
        private System.Windows.Forms.Button button_DepModify;
    }
}