﻿namespace Hisaab_Kitaab
{
    partial class List_Inventory_Head_Add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_Next = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_AccTitle = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_parentHead = new System.Windows.Forms.TextBox();
            this.label_Add = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_Next
            // 
            this.button_Next.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.button_Next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Next.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Next.ForeColor = System.Drawing.Color.White;
            this.button_Next.Location = new System.Drawing.Point(340, 229);
            this.button_Next.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_Next.Name = "button_Next";
            this.button_Next.Size = new System.Drawing.Size(155, 46);
            this.button_Next.TabIndex = 11;
            this.button_Next.Text = "Add";
            this.button_Next.UseVisualStyleBackColor = false;
            this.button_Next.Click += new System.EventHandler(this.button_Next_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label2.Location = new System.Drawing.Point(49, 166);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 24);
            this.label2.TabIndex = 10;
            this.label2.Text = "Account Title:";
            // 
            // textBox_AccTitle
            // 
            this.textBox_AccTitle.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_AccTitle.Location = new System.Drawing.Point(233, 163);
            this.textBox_AccTitle.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_AccTitle.Name = "textBox_AccTitle";
            this.textBox_AccTitle.Size = new System.Drawing.Size(376, 31);
            this.textBox_AccTitle.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label1.Location = new System.Drawing.Point(50, 109);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 24);
            this.label1.TabIndex = 8;
            this.label1.Text = "Parent Head:";
            // 
            // textBox_parentHead
            // 
            this.textBox_parentHead.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_parentHead.Location = new System.Drawing.Point(232, 103);
            this.textBox_parentHead.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_parentHead.Name = "textBox_parentHead";
            this.textBox_parentHead.Size = new System.Drawing.Size(377, 31);
            this.textBox_parentHead.TabIndex = 6;
            this.textBox_parentHead.TextChanged += new System.EventHandler(this.textBox_parentHead_TextChanged);
            // 
            // label_Add
            // 
            this.label_Add.AutoSize = true;
            this.label_Add.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Add.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.label_Add.Location = new System.Drawing.Point(270, 32);
            this.label_Add.Name = "label_Add";
            this.label_Add.Size = new System.Drawing.Size(253, 29);
            this.label_Add.TabIndex = 12;
            this.label_Add.Text = "Add Inventory Head";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(116)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(625, 94);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(155, 46);
            this.button1.TabIndex = 13;
            this.button1.Text = "Choose";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // List_Inventory_Head_Add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(809, 337);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label_Add);
            this.Controls.Add(this.button_Next);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_AccTitle);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_parentHead);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "List_Inventory_Head_Add";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "List_Inventory_Head_Add";
            this.Load += new System.EventHandler(this.List_Inventory_Head_Add_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_Next;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_AccTitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_Add;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.TextBox textBox_parentHead;
    }
}